importScripts('focus-worker.js', 'focus-st.js');

async function publishStandup(text) {
  const channel = await getChatChannel('qa-standup');
  const headers = await chatPostHeaders();
  const response = await fetch(chatOrigin + '/api/v4/posts', {
    ...options, method: 'POST', headers, signal: AbortSignal.timeout(20000),
    body: JSON.stringify({channel_id: channel.id, message: text})
  }).catch(() => { throw new Error('Нет ответа от Platrum. Проверьте qa-standup перед повторной отправкой.'); });
  if (response.status === 401 || response.status === 403) throw new Error('Проверьте вход в Platrum и право писать в qa-standup.');
  const post = response.ok && await response.json().catch(() => null);
  if (!post || post.channel_id !== channel.id || !/^[a-z0-9]{26}$/.test(post.id)) {
    throw new Error('Platrum не подтвердил отправку. Проверьте канал qa-standup.');
  }
  return {id: post.id};
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['standup:post', 'standup:send'].includes(message?.type) || sender.frameId !== 0 || !sender.tab || !sender.url) return;
  const page = new URL(sender.url);
  if (page.origin !== 'https://lidia932.github.io' || page.pathname !== '/qa-workbench-pages/standup.html') return;
  if (message.type === 'standup:send') {
    if (typeof message.text !== 'string' || !message.text.trim()) { reply({error: 'Сообщение пустое.'}); return; }
    publishStandup(message.text).then(reply, error => reply({error: error.message}));
    return true;
  }
  if (!/^[a-z0-9]{26}$/.test(message.id)) return;
  (async () => {
    const response = await fetch('https://roistat.chat.platrum.ru/api/v4/posts/' + message.id,
      {credentials: 'include', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000)});
    if (!response.ok) throw new Error('Platrum: HTTP ' + response.status + '. Проверьте вход и доступ к сообщению.');
    const post = await response.json();
    if (post.id !== message.id || typeof post.message !== 'string') throw new Error('Platrum не вернул сообщение.');
    const match = post.message.match(/^(?:[\s*#_]*?)Сегодня\s*:?[*_ \t]*\r?\n([\s\S]*?)(?=^[ \t*#_]*(?:Проблемы|Вчера)\s*:?[*_ \t]*$|(?![\s\S]))/im);
    if (!match) throw new Error('В сообщении не найден раздел «Сегодня».');
    reply({today: match[1], date: post.create_at});
  })().catch(error => reply({error: error.message}));
  return true;
});
