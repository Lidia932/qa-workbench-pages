(() => {
  if (window !== window.top || location.pathname !== '/qa-workbench-pages/standup.html') return;
  const panel = document.querySelector('#standup-reminder');
  if (!panel) return;
  const form = panel.querySelector('form');
  const fields = form.elements;
  const status = panel.querySelector('[role=status]');
  const bell = panel.querySelector('summary');
  function display(settings) {
    fields.enabled.checked = settings.enabled;
    fields.time.value = settings.time;
    fields.zone.value = settings.zone;
    fields.text.value = settings.text;
    bell.dataset.enabled = String(settings.enabled);
    bell.title = settings.enabled ? 'Напоминание включено · ' + settings.time : 'Настроить напоминание';
  }
  async function load() {
    try {
      const result = await chrome.runtime.sendMessage({type: 'standup:reminder-read'});
      if (!result?.settings) throw new Error(result?.error);
      display(result.settings);
      panel.querySelector('.reminder-help').hidden = true;
      form.hidden = false;
    } catch { status.textContent = 'Не удалось загрузить настройки. Обновите вкладку и попробуйте ещё раз.'; }
  }
  load();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.standupReminder?.newValue && !panel.open) display(changes.standupReminder.newValue);
  });
  panel.addEventListener('toggle', () => {
    if (panel.open) { status.textContent = ''; load(); }
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!event.isTrusted || !navigator.userActivation.isActive || fields.save.disabled) return;
    fields.save.disabled = true;
    try {
      const settings = {enabled: fields.enabled.checked, time: fields.time.value, zone: fields.zone.value, text: fields.text.value};
      const result = await chrome.runtime.sendMessage({type: 'standup:reminder-save', settings});
      if (!result?.settings) throw new Error(result?.error || 'Расширение не ответило. Обновите вкладку.');
      display(result.settings);
      status.textContent = settings.enabled ? 'Напоминание сохранено для этого профиля.' : 'Напоминание выключено.';
    } catch (error) { status.textContent = error.message; }
    finally { fields.save.disabled = false; }
  });
})();
