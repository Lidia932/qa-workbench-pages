const reminderId = 'qa-standup-reminder';
const standupUrl = 'https://lidia932.github.io/qa-workbench-pages/standup.html';
const reminderDefaults = {enabled: false, time: '11:30', zone: 'moscow', text: 'Пора отправить стендап в qa-standup.'};
let reminderWork = Promise.resolve();

function queueReminder(task) {
  const result = reminderWork.then(task);
  reminderWork = result.catch(console.error);
  return result;
}

// Moscow uses UTC+3. Local schedules use calendar setters to follow the device's DST.
function weekdaySlot(timestamp, daysAhead, {time, zone}) {
  const [hours, minutes] = time.split(':').map(Number);
  const moscowOffset = 3 * 60 * 60 * 1000;
  const date = new Date(timestamp + (zone === 'moscow' ? moscowOffset : 0));
  if (zone === 'moscow') {
    date.setUTCDate(date.getUTCDate() + daysAhead);
    date.setUTCHours(hours, minutes, 0, 0);
    return {weekday: date.getUTCDay(), when: date.getTime() - moscowOffset};
  }
  date.setDate(date.getDate() + daysAhead);
  date.setHours(hours, minutes, 0, 0);
  return {weekday: date.getDay(), when: date.getTime()};
}

async function scheduleReminder() {
  const {standupReminder: settings, standupSentAt, standupNotifiedAt} =
    await chrome.storage.local.get(['standupReminder', 'standupSentAt', 'standupNotifiedAt']);
  if (!settings?.enabled) {
    await chrome.alarms.clear(reminderId);
    return;
  }
  const now = Date.now();
  const today = weekdaySlot(now, 0, settings);
  const alreadyHandled = [standupSentAt, standupNotifiedAt].some(stamp =>
    stamp && weekdaySlot(stamp, 0, settings).when === today.when);
  const eligibleToday = today.weekday > 0 && today.weekday < 6 && !alreadyHandled && today.when >= settings.since;
  let next = today;
  if (!eligibleToday || today.when <= now) {
    let days = 1;
    do { next = weekdaySlot(now, days++, settings); } while (next.weekday === 0 || next.weekday === 6);
  }
  const alarm = await chrome.alarms.get(reminderId);
  if (alarm?.scheduledTime !== next.when) await chrome.alarms.create(reminderId, {when: next.when});
  if (eligibleToday && today.when <= now) {
    await chrome.notifications.create(reminderId, {
      type: 'basic', iconUrl: 'icons/icon-128.png', title: 'Roistat QA · Стендап', message: settings.text
    });
    await chrome.storage.local.set({standupNotifiedAt: now});
  }
}

function recordStandupDelivery() {
  const sentAt = Date.now();
  return queueReminder(async () => {
    await chrome.storage.local.set({standupSentAt: sentAt});
    await chrome.notifications.clear(reminderId);
    await scheduleReminder();
  });
}

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === reminderId) queueReminder(scheduleReminder);
});
chrome.runtime.onStartup.addListener(() => queueReminder(scheduleReminder));
queueReminder(scheduleReminder);

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['standup:reminder-read', 'standup:reminder-save'].includes(message?.type) ||
      sender.frameId !== 0 || !sender.tab || !sender.url) return;
  const page = new URL(sender.url);
  if (page.origin + page.pathname !== standupUrl) return;
  queueReminder(async () => {
    if (message.type === 'standup:reminder-read') {
      const {standupReminder} = await chrome.storage.local.get('standupReminder');
      return {settings: standupReminder || reminderDefaults};
    }
    const {enabled, time, zone, text} = message.settings || {};
    if (typeof enabled !== 'boolean' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time) ||
        !['moscow','local'].includes(zone) || typeof text !== 'string' || text.length > 200) {
      throw new Error('Проверьте время, часовой пояс и текст.');
    }
    if (enabled && await chrome.notifications.getPermissionLevel() !== 'granted') {
      throw new Error('Разрешите уведомления QA Merge Checker в Chrome и сохраните настройки ещё раз.');
    }
    const settings = {enabled, time, zone, text: text.trim() || reminderDefaults.text, since: Date.now()};
    await chrome.storage.local.set({standupReminder: settings});
    if (!enabled) await chrome.notifications.clear(reminderId);
    await scheduleReminder();
    return {settings};
  }).then(reply, error => reply({error: error.message}));
  return true;
});

chrome.notifications.onClicked.addListener(async id => {
  if (id !== reminderId) return;
  await chrome.notifications.clear(id);
  const tabs = await chrome.tabs.query({url: standupUrl + '*'});
  const tab = tabs.find(item => new URL(item.url).pathname === '/qa-workbench-pages/standup.html');
  if (tab) {
    await chrome.tabs.update(tab.id, {active: true});
    await chrome.windows.update(tab.windowId, {focused: true});
  } else await chrome.tabs.create({url: standupUrl});
});
