const settings = document.getElementById("settings");
const statusNode = document.getElementById("status");
const lightThemeButton = document.getElementById("lightTheme");
const darkThemeButton = document.getElementById("darkTheme");
const badgeVisibilityInput = document.getElementById("badgeVisibility");
const badgeVisibilityText = document.getElementById("badgeVisibilityText");

let currentTheme = "light";

function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

function setStatus(text) {
  statusNode.textContent = text;
}

function applyTheme(theme) {
  currentTheme = theme === "dark" ? "dark" : "light";
  document.body.dataset.theme = currentTheme;
  lightThemeButton.classList.toggle("is-active", currentTheme === "light");
  darkThemeButton.classList.toggle("is-active", currentTheme === "dark");
}

function applyBadgeVisibility(visible) {
  badgeVisibilityInput.checked = visible !== false;
  badgeVisibilityText.textContent = badgeVisibilityInput.checked
    ? "Показывать поверх сайта"
    : "Скрыт на странице";
}

function createSetting(state) {
  const row = document.createElement("article");
  const copy = document.createElement("div");
  const title = document.createElement("p");
  const text = document.createElement("p");
  const label = document.createElement("label");
  const input = document.createElement("input");
  const slider = document.createElement("span");

  row.className = "setting";
  title.className = "setting-title";
  text.className = "setting-text";
  label.className = "switch";
  slider.className = "slider";

  title.textContent = state.label;
  text.textContent = state.cookieText || `${state.name}=${state.value ?? "не задана"}`;
  input.type = "checkbox";
  input.checked = state.state === "enabled";
  input.disabled = state.state === "unsupported";
  input.setAttribute("aria-label", `${state.label}: включить или выключить`);

  input.addEventListener("change", async () => {
    input.disabled = true;
    setStatus(`Сохраняю ${state.name}=${input.checked ? "1" : "0"}...`);

    const response = await sendMessage({
      type: "SET_FEATURE_COOKIE",
      name: state.name,
      enabled: input.checked
    });

    if (!response?.ok) {
      input.checked = !input.checked;
      input.disabled = false;
      setStatus(response?.error || "Не удалось изменить cookie.");
      return;
    }

    render(response.states);
    setStatus("Cookie изменена. Бейдж на странице обновится после перезагрузки вкладки.");
  });

  copy.append(title, text);
  label.append(input, slider);
  row.append(copy, label);
  return row;
}

function render(states) {
  settings.replaceChildren(...states.map(createSetting));
}

async function setTheme(theme) {
  applyTheme(theme);
  setStatus("Сохраняю тему оформления...");

  const response = await sendMessage({
    type: "SET_THEME",
    theme
  });

  if (!response?.ok) {
    setStatus(response?.error || "Не удалось сохранить тему.");
    return;
  }

  applyTheme(response.theme);
  setStatus("Тема применена к настройкам и бейджу.");
}

async function setBadgeVisibility(visible) {
  badgeVisibilityInput.disabled = true;
  applyBadgeVisibility(visible);
  setStatus(visible ? "Включаю бейдж на странице..." : "Отключаю бейдж на странице...");

  const response = await sendMessage({
    type: "SET_BADGE_VISIBILITY",
    visible
  });

  badgeVisibilityInput.disabled = false;

  if (!response?.ok) {
    applyBadgeVisibility(!visible);
    setStatus(response?.error || "Не удалось изменить отображение бейджа.");
    return;
  }

  applyBadgeVisibility(response.badgeVisible);
  setStatus(response.badgeVisible ? "Бейдж на странице включен." : "Бейдж на странице отключен.");
}

async function init() {
  const response = await sendMessage({ type: "GET_FEATURE_COOKIE_STATES" });

  if (!response?.ok) {
    setStatus(response?.error || "Не удалось прочитать cookie.");
    return;
  }

  applyTheme(response.theme);
  applyBadgeVisibility(response.badgeVisible);
  render(response.states);
  setStatus("Настройки текущего сайта. Изменения cookie на странице видны после перезагрузки вкладки.");
}

lightThemeButton.addEventListener("click", () => setTheme("light"));
darkThemeButton.addEventListener("click", () => setTheme("dark"));
badgeVisibilityInput.addEventListener("change", () => setBadgeVisibility(badgeVisibilityInput.checked));

init();
