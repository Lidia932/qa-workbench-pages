(() => {
const SCRIPT_INSTANCE_KEY = "__betaCookieIndicatorScriptInstance";
const SCRIPT_INSTANCE_ID = `${Date.now()}-${Math.random()}`;
window[SCRIPT_INSTANCE_KEY] = SCRIPT_INSTANCE_ID;
const INDICATOR_ID = "beta-cookie-indicator";
const POSITION_KEY = "indicatorPosition";
const POSITIONS_KEY = "indicatorPositions";
const DISABLED_ROWS_KEY = "disabledRowsExpanded";
const TOP_BAR_THRESHOLD = 135;
const TOP_BAR_HYSTERESIS = 18;
const POSITION_SAVE_DELAY = 120;
let currentPosition = null;
let positionSaveTimer = null;
let renderSeq = 0;

function getPagePositionKey() {
  return `${location.origin}${location.pathname}`;
}

function isActiveScriptInstance() {
  return window[SCRIPT_INSTANCE_KEY] === SCRIPT_INSTANCE_ID;
}

function safeRun(callback) {
  try {
    return callback();
  } catch (error) {
    if (String(error?.message || error).includes("Extension context invalidated")) {
      return undefined;
    }

    throw error;
  }
}
const THEME_STYLES = {
  light: {
    panelBackground: "rgba(255, 255, 255, 0.68)",
    panelBorder: "rgba(255, 255, 255, 0.74)",
    panelShadow: "0 8px 22px rgba(15, 23, 42, 0.1)",
    headerBackground: "rgba(255, 255, 255, 0.48)",
    rowBackground: "rgba(255, 255, 255, 0.36)",
    title: "#111827",
    muted: "#475569",
    enabled: "#075c27",
    disabled: "#374151",
    warning: "#92400e",
    enabledBadge: "#0f8a3b",
    disabledBadge: "#6b7280",
    warningBadge: "#b45309",
    dangerBackground: "rgba(220, 38, 38, 0.9)",
    dangerText: "#ffffff",
    dangerShadow: "0 7px 18px rgba(220, 38, 38, 0.18)"
  },
  dark: {
    panelBackground: "rgba(15, 23, 42, 0.62)",
    panelBorder: "rgba(148, 163, 184, 0.26)",
    panelShadow: "0 9px 24px rgba(0, 0, 0, 0.2)",
    headerBackground: "rgba(15, 23, 42, 0.34)",
    rowBackground: "rgba(255, 255, 255, 0.06)",
    title: "#f9fafb",
    muted: "#cbd5e1",
    enabled: "#86efac",
    disabled: "#d1d5db",
    warning: "#fbbf24",
    enabledBadge: "#16a34a",
    disabledBadge: "#64748b",
    warningBadge: "#d97706",
    dangerBackground: "rgba(239, 68, 68, 0.88)",
    dangerText: "#ffffff",
    dangerShadow: "0 8px 20px rgba(239, 68, 68, 0.18)"
  }
};

function getTheme(theme) {
  return THEME_STYLES[theme] ? theme : "light";
}

function isTopBarPosition(top) {
  return Number.isFinite(top) && top <= TOP_BAR_THRESHOLD;
}

function getNextDockedState(top, currentDocked) {
  if (!Number.isFinite(top)) {
    return currentDocked;
  }

  if (currentDocked) {
    return top <= TOP_BAR_THRESHOLD + TOP_BAR_HYSTERESIS;
  }

  return top <= TOP_BAR_THRESHOLD - TOP_BAR_HYSTERESIS;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function getStateColor(state, theme) {
  const palette = THEME_STYLES[getTheme(theme)];

  if (state === "enabled") {
    return palette.enabled;
  }

  if (state === "disabled") {
    return palette.disabled;
  }

  return palette.warning;
}

function getStateBadgeColor(state, theme) {
  const palette = THEME_STYLES[getTheme(theme)];

  if (state === "enabled") {
    return palette.enabledBadge;
  }

  if (state === "disabled") {
    return palette.disabledBadge;
  }

  return palette.warningBadge;
}

function getStateText(state) {
  if (state === "enabled") {
    return "ON";
  }

  if (state === "disabled") {
    return "OFF";
  }

  return "N/A";
}

function isCollapsibleState(state) {
  return state.state !== "enabled";
}

function getVisibleStates(states, inactiveRowsExpanded) {
  if (inactiveRowsExpanded) {
    return states;
  }

  return states.filter((state) => !isCollapsibleState(state));
}

function createRow(state, theme) {
  const palette = THEME_STYLES[getTheme(theme)];
  const row = document.createElement("div");
  const status = document.createElement("span");
  const text = document.createElement("span");

  row.dataset.role = "flag-row";
  status.dataset.role = "flag-status";
  text.dataset.role = "flag-text";
  status.textContent = getStateText(state.state);
  text.textContent = state.text;

  Object.assign(row.style, {
    display: "grid",
    gridTemplateColumns: "34px minmax(180px, 1fr)",
    gap: "8px",
    alignItems: "start",
    padding: "6px 7px",
    borderRadius: "7px",
    background: palette.rowBackground
  });

  Object.assign(status.style, {
    display: "inline-flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "18px",
    borderRadius: "5px",
    background: getStateBadgeColor(state.state, theme),
    color: "#ffffff",
    fontSize: "10px",
    fontWeight: "700"
  });

  Object.assign(text.style, {
    color: getStateColor(state.state, theme),
    overflowWrap: "anywhere"
  });

  row.append(status, text);
  return row;
}

function createDisabledToggle(states, disabledRowsExpanded, theme, onToggle) {
  const disabledCount = states.filter(isCollapsibleState).length;
  const palette = THEME_STYLES[getTheme(theme)];
  const button = document.createElement("button");

  button.type = "button";
  button.dataset.role = "disabled-toggle";
  button.textContent = disabledCount === 0
    ? "drag"
    : disabledRowsExpanded
      ? `hide OFF (${disabledCount})`
      : `show OFF (${disabledCount})`;
  button.disabled = disabledCount === 0;

  Object.assign(button.style, {
    minHeight: "20px",
    padding: "2px 6px",
    border: `1px solid ${palette.panelBorder}`,
    borderRadius: "6px",
    background: palette.rowBackground,
    color: palette.muted,
    cursor: disabledCount === 0 ? "move" : "pointer",
    fontSize: "10px",
    fontWeight: "800",
    textTransform: "uppercase"
  });

  button.addEventListener("pointerdown", (event) => {
    if (disabledCount > 0) {
      event.stopPropagation();
    }
  });

  button.addEventListener("click", (event) => {
    if (disabledCount === 0) {
      return;
    }

    event.stopPropagation();
    onToggle(!disabledRowsExpanded);
  });

  return button;
}

function createDeployWarning(theme) {
  const palette = THEME_STYLES[getTheme(theme)];
  const warning = document.createElement("div");
  const title = document.createElement("div");
  const text = document.createElement("div");

  warning.dataset.role = "deploy-warning";
  title.dataset.role = "deploy-warning-title";
  text.dataset.role = "deploy-warning-text";
  title.textContent = "ВНИМАНИЕ: БЕТА-СЕРВЕР";
  text.textContent = "Выключить бета-сервер перед деплоем";

  Object.assign(warning.style, {
    display: "grid",
    gap: "3px",
    padding: "9px 10px",
    borderRadius: "8px",
    background: palette.dangerBackground,
    color: palette.dangerText,
    boxShadow: palette.dangerShadow
  });

  Object.assign(title.style, {
    fontSize: "13px",
    fontWeight: "900",
    lineHeight: "17px",
    textTransform: "uppercase"
  });

  Object.assign(text.style, {
    fontSize: "12px",
    fontWeight: "700",
    lineHeight: "16px"
  });

  warning.append(title, text);
  return warning;
}

function applySavedPosition(indicator, position) {
  if (!isActiveScriptInstance()) {
    return null;
  }

  const nextPosition = currentPosition || position;

  if (nextPosition && Number.isFinite(nextPosition.left) && Number.isFinite(nextPosition.top)) {
    const maxLeft = Math.max(8, window.innerWidth - indicator.offsetWidth - 8);
    const maxTop = Math.max(8, window.innerHeight - indicator.offsetHeight - 8);
    currentPosition = {
      left: clamp(nextPosition.left, 8, maxLeft),
      top: clamp(nextPosition.top, 8, maxTop)
    };
    indicator.style.left = `${currentPosition.left}px`;
    indicator.style.top = `${currentPosition.top}px`;
    indicator.style.right = "auto";
    return currentPosition;
  }

  indicator.style.top = "12px";
  indicator.style.right = "12px";
  indicator.style.left = "auto";
  return null;
}

function persistPosition(position) {
  if (!isActiveScriptInstance()) {
    return position;
  }

  currentPosition = position;

  if (!isExtensionContextAlive()) {
    return position;
  }

  getStorage(POSITIONS_KEY).then((storage) => safeRun(() => {
    if (!isActiveScriptInstance()) {
      return;
    }

    const positions = storage[POSITIONS_KEY] && typeof storage[POSITIONS_KEY] === "object"
      ? storage[POSITIONS_KEY]
      : {};

    setStorage({
      [POSITION_KEY]: position,
      [POSITIONS_KEY]: {
        ...positions,
        [getPagePositionKey()]: position
      }
    });
  }));

  return position;
}

function savePosition(indicator) {
  if (!isActiveScriptInstance()) {
    return currentPosition;
  }

  const rect = indicator.getBoundingClientRect();
  return persistPosition({
    left: Math.round(rect.left),
    top: Math.round(rect.top)
  });
}

function schedulePositionSave(indicator) {
  if (!isActiveScriptInstance()) {
    return;
  }

  currentPosition = {
    left: Math.round(indicator.getBoundingClientRect().left),
    top: Math.round(indicator.getBoundingClientRect().top)
  };

  if (positionSaveTimer) {
    clearTimeout(positionSaveTimer);
  }

  positionSaveTimer = setTimeout(() => {
    safeRun(() => {
    if (!isActiveScriptInstance()) {
      return;
    }

    positionSaveTimer = null;
    savePosition(indicator);
    });
  }, POSITION_SAVE_DELAY);
}

function getStoredPosition(storage) {
  const positions = storage[POSITIONS_KEY];
  const pagePosition = positions && typeof positions === "object"
    ? positions[getPagePositionKey()]
    : null;

  return pagePosition || storage[POSITION_KEY] || null;
}

function isExtensionContextAlive() {
  try {
    return Boolean(globalThis.chrome?.runtime?.id && chrome.storage?.local);
  } catch {
    return false;
  }
}

function getStorage(keys) {
  if (!isExtensionContextAlive()) {
    return Promise.resolve({});
  }

  try {
    return chrome.storage.local.get(keys).catch(() => ({}));
  } catch {
    return Promise.resolve({});
  }
}

function setStorage(values) {
  if (!isExtensionContextAlive()) {
    return Promise.resolve();
  }

  try {
    return chrome.storage.local.set(values).catch(() => {});
  } catch {
    return Promise.resolve();
  }
}

function applyIndicatorLayout(indicator, docked, theme) {
  if (!isActiveScriptInstance()) {
    return;
  }

  const palette = THEME_STYLES[getTheme(theme)];
  const rows = indicator.querySelectorAll('[data-role="flag-row"]');
  const statuses = indicator.querySelectorAll('[data-role="flag-status"]');
  const title = indicator.querySelector('[data-role="indicator-title"]');
  const titleText = indicator.querySelector('[data-role="indicator-title-text"]');
  const toggle = indicator.querySelector('[data-role="disabled-toggle"]');
  const warning = indicator.querySelector('[data-role="deploy-warning"]');
  const warningTitle = indicator.querySelector('[data-role="deploy-warning-title"]');
  const warningText = indicator.querySelector('[data-role="deploy-warning-text"]');

  indicator.dataset.layout = docked ? "topbar" : "card";

  Object.assign(indicator.style, {
    display: docked ? "flex" : "grid",
    alignItems: docked ? "center" : "stretch",
    gap: docked ? "6px" : "5px",
    width: docked ? "max-content" : "auto",
    maxWidth: docked ? "calc(100vw - 16px)" : "430px",
    minHeight: docked ? "34px" : "auto",
    maxHeight: docked ? "42px" : "none",
    padding: docked ? "5px 7px" : "8px",
    overflow: docked ? "hidden" : "visible",
    borderRadius: docked ? "9px" : "10px",
    transition: "width 120ms ease, max-width 120ms ease, min-height 120ms ease, max-height 120ms ease, padding 120ms ease, border-radius 120ms ease"
  });

  if (title) {
    Object.assign(title.style, {
      flex: docked ? "0 0 auto" : "",
      gap: docked ? "8px" : "",
      marginBottom: docked ? "0" : "4px",
      padding: docked ? "4px 8px" : "6px 8px",
      minHeight: docked ? "24px" : "auto",
      minWidth: docked ? "168px" : "auto"
    });
  }

  if (titleText) {
    Object.assign(titleText.style, {
      flex: "0 0 auto",
      minWidth: "72px",
      whiteSpace: "nowrap"
    });
  }

  if (toggle) {
    Object.assign(toggle.style, {
      minHeight: docked ? "18px" : "20px",
      padding: docked ? "1px 5px" : "2px 6px",
      whiteSpace: "nowrap"
    });
  }

  if (warning) {
    Object.assign(warning.style, {
      display: docked ? "flex" : "grid",
      alignItems: docked ? "center" : "stretch",
      gap: docked ? "7px" : "3px",
      padding: docked ? "5px 8px" : "9px 10px",
      minHeight: docked ? "24px" : "auto",
      boxShadow: docked ? "none" : palette.dangerShadow,
      whiteSpace: docked ? "nowrap" : "normal"
    });
  }

  if (warningTitle) {
    warningTitle.style.fontSize = docked ? "11px" : "13px";
  }

  if (warningText) {
    warningText.style.fontSize = docked ? "11px" : "12px";
  }

  rows.forEach((row) => {
    Object.assign(row.style, {
      display: docked ? "flex" : "grid",
      gridTemplateColumns: docked ? "" : "34px minmax(180px, 1fr)",
      alignItems: "center",
      gap: docked ? "5px" : "8px",
      padding: docked ? "4px 8px" : "6px 7px",
      minHeight: docked ? "24px" : "auto",
      whiteSpace: docked ? "nowrap" : "normal"
    });
  });

  statuses.forEach((status) => {
    Object.assign(status.style, {
      flex: "0 0 auto",
      minWidth: docked ? "25px" : "",
      minHeight: docked ? "16px" : "18px",
      padding: docked ? "0 3px" : "",
      fontSize: docked ? "8px" : "10px"
    });
  });

  indicator.querySelectorAll('[data-role="flag-text"]').forEach((text) => {
    Object.assign(text.style, {
      display: "inline-block",
      maxWidth: docked ? "190px" : "none",
      overflow: docked ? "hidden" : "visible",
      textOverflow: docked ? "ellipsis" : "clip",
      whiteSpace: docked ? "nowrap" : "normal"
    });
  });
}

function enableDragging(indicator, theme) {
  if (!isActiveScriptInstance()) {
    return;
  }

  if (indicator.dataset.dragReady === "true") {
    return;
  }

  indicator.dataset.dragReady = "true";
  let drag = null;

  function move(event) {
    if (!isActiveScriptInstance() || !drag || drag.pointerId !== event.pointerId) {
      return;
    }

    event.preventDefault();
    const nextDocked = getNextDockedState(event.clientY - drag.offsetY, drag.docked);

    if (nextDocked !== drag.docked) {
      const ratioX = drag.offsetX / Math.max(1, indicator.offsetWidth);
      const ratioY = drag.offsetY / Math.max(1, indicator.offsetHeight);

      applyIndicatorLayout(indicator, nextDocked, theme);
      drag.docked = nextDocked;
      drag.offsetX = clamp(indicator.offsetWidth * ratioX, 8, Math.max(8, indicator.offsetWidth - 8));
      drag.offsetY = clamp(indicator.offsetHeight * ratioY, 8, Math.max(8, indicator.offsetHeight - 8));
    }

    const maxLeft = Math.max(8, window.innerWidth - indicator.offsetWidth - 8);
    const maxTop = Math.max(8, window.innerHeight - indicator.offsetHeight - 8);
    const left = Math.min(Math.max(8, event.clientX - drag.offsetX), maxLeft);
    const top = Math.min(Math.max(8, event.clientY - drag.offsetY), maxTop);

    indicator.style.left = `${left}px`;
    indicator.style.top = `${top}px`;
    indicator.style.right = "auto";
    currentPosition = {
      left: Math.round(left),
      top: Math.round(top)
    };
    schedulePositionSave(indicator);
  }

  function stop(event) {
    if (!isActiveScriptInstance() || !drag || drag.pointerId !== event.pointerId) {
      return;
    }

    drag = null;
    document.removeEventListener("pointermove", move, true);
    document.removeEventListener("pointerup", stop, true);
    document.removeEventListener("pointercancel", stop, true);
    applyIndicatorLayout(indicator, isTopBarPosition(indicator.getBoundingClientRect().top), theme);
    savePosition(indicator);
  }

  indicator.addEventListener("pointerdown", (event) => safeRun(() => {
    if (!isActiveScriptInstance()) {
      return;
    }

    if (event.button !== 0) {
      return;
    }

    if (event.target.closest('[data-role="disabled-toggle"]')) {
      return;
    }

    event.preventDefault();
    const rect = indicator.getBoundingClientRect();
    drag = {
      pointerId: event.pointerId,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top,
      docked: indicator.dataset.layout === "topbar"
    };
    document.addEventListener("pointermove", move, true);
    document.addEventListener("pointerup", stop, true);
    document.addEventListener("pointercancel", stop, true);
  }));
}

function showIndicator(states, theme, deployWarning) {
  if (!isActiveScriptInstance()) {
    return;
  }

  const renderId = String(++renderSeq);
  const currentTheme = getTheme(theme);
  const palette = THEME_STYLES[currentTheme];
  let indicator = document.getElementById(INDICATOR_ID);

  if (!indicator) {
    indicator = document.createElement("div");
    indicator.id = INDICATOR_ID;
    indicator.setAttribute("role", "status");
    indicator.setAttribute("aria-live", "polite");
    document.documentElement.appendChild(indicator);
  }

  indicator.replaceChildren();
  indicator.dataset.theme = currentTheme;
  indicator.dataset.renderId = renderId;

  const title = document.createElement("div");
  title.dataset.role = "indicator-title";
  Object.assign(title.style, {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "4px",
    padding: "6px 8px",
    borderRadius: "7px",
    background: palette.headerBackground,
    color: palette.title,
    fontSize: "12px",
    fontWeight: "700",
    cursor: "move",
    userSelect: "none"
  });

  Object.assign(indicator.style, {
    position: "fixed",
    zIndex: "2147483647",
    display: "grid",
    gap: "5px",
    maxWidth: "430px",
    padding: "8px",
    border: `1px solid ${palette.panelBorder}`,
    borderRadius: "10px",
    background: palette.panelBackground,
    boxShadow: palette.panelShadow,
    backdropFilter: "blur(14px) saturate(135%)",
    fontFamily: "Arial, sans-serif",
    fontSize: "13px",
    fontWeight: "600",
    lineHeight: "17px",
    pointerEvents: "auto"
  });

  getStorage([POSITION_KEY, POSITIONS_KEY, DISABLED_ROWS_KEY]).then((storage) => safeRun(() => {
    if (!isActiveScriptInstance() || indicator.dataset.renderId !== renderId) {
      return;
    }

    const disabledRowsExpanded = storage[DISABLED_ROWS_KEY] === true;
    const visibleStates = getVisibleStates(states, disabledRowsExpanded);
    const titleText = document.createElement("span");
    const toggle = createDisabledToggle(states, disabledRowsExpanded, currentTheme, (expanded) => {
      const savedPosition = savePosition(indicator);
      setStorage({
        [DISABLED_ROWS_KEY]: expanded,
        [POSITION_KEY]: savedPosition
      }).then(() => {
        safeRun(() => {
        if (!isActiveScriptInstance()) {
          return;
        }

        showIndicator(states, currentTheme, deployWarning);
        });
      });
    });

    titleText.dataset.role = "indicator-title-text";
    titleText.textContent = "Cookie flags";
    title.append(titleText, toggle);
    indicator.replaceChildren();
    indicator.append(title);

    if (deployWarning) {
      indicator.append(createDeployWarning(currentTheme));
    }

    indicator.append(...visibleStates.map((state) => createRow(state, currentTheme)));

    const storedPosition = getStoredPosition(storage);
    applyIndicatorLayout(indicator, Boolean(storedPosition && isTopBarPosition(storedPosition.top)), currentTheme);
    const position = applySavedPosition(indicator, storedPosition);
    applyIndicatorLayout(indicator, Boolean(position && isTopBarPosition(position.top)), currentTheme);
  }));

  enableDragging(indicator, currentTheme);
}

function hideIndicator() {
  if (!isActiveScriptInstance()) {
    return;
  }

  document.getElementById(INDICATOR_ID)?.remove();
}

function saveCurrentIndicatorPosition() {
  if (!isActiveScriptInstance()) {
    return;
  }

  const indicator = document.getElementById(INDICATOR_ID);

  if (indicator) {
    savePosition(indicator);
  }
}

function applyState(states, theme, deployWarning) {
  if (!isActiveScriptInstance()) {
    return;
  }

  if (Array.isArray(states) && states.length > 0) {
    showIndicator(states, theme, deployWarning);
  } else {
    hideIndicator();
  }
}

window.addEventListener("blur", () => safeRun(saveCurrentIndicatorPosition));
window.addEventListener("pagehide", () => safeRun(saveCurrentIndicatorPosition));
document.addEventListener("visibilitychange", () => safeRun(() => {
  if (document.visibilityState === "hidden") {
    saveCurrentIndicatorPosition();
  }
}));

if (isExtensionContextAlive()) {
  safeRun(() => chrome.runtime.onMessage.addListener((message) => safeRun(() => {
    if (!isActiveScriptInstance()) {
      return;
    }

    if (message?.type === "FEATURE_COOKIE_STATE") {
      if (message.visible === false) {
        hideIndicator();
        return;
      }

      applyState(message.states, message.theme, Boolean(message.deployWarning));
    }
  })));
}
})();
