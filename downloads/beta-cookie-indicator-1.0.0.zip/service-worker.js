const ENABLED_VALUE = "1";
const DISABLED_VALUE = "0";
const DEPLOY_URL = "https://cloud.roistat.com/admin/deploy";
const THEMES = {
  light: {
    actionBadgeColor: "#0f8a3b",
    inactiveActionBadgeColor: "#6b7280",
    warningActionBadgeColor: "#dc2626"
  },
  dark: {
    actionBadgeColor: "#7c3aed",
    inactiveActionBadgeColor: "#4b5563",
    warningActionBadgeColor: "#ef4444"
  }
};
const COOKIE_FLAGS = [
  {
    name: "beta_server",
    label: "Бета-сервер",
    enabledText: "включен бета-сервер",
    disabledText: "бета-сервер отключен"
  },
  {
    name: "is_background_reports",
    label: "Выгрузка файлов в фон",
    enabledText: "включена выгрузка файлов в фон",
    disabledText: "выгрузка файлов в фон отключена"
  },
  {
    name: "beta_test",
    label: "Бета-тест",
    enabledText: "включен бета-тест",
    disabledText: "бета-тест отключен"
  }
];

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isInspectableUrl(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url);
}

async function getCookieStoreId(tab) {
  if (!tab || typeof tab.id !== "number") {
    return undefined;
  }

  const stores = await chrome.cookies.getAllCookieStores();
  const store = stores.find((cookieStore) => cookieStore.tabIds.includes(tab.id));
  return store?.id;
}

function isDeployPage(url) {
  try {
    const pageUrl = new URL(url);
    const deployUrl = new URL(DEPLOY_URL);
    return pageUrl.origin === deployUrl.origin && pageUrl.pathname === deployUrl.pathname;
  } catch {
    return false;
  }
}

function hasEnabledBetaServer(states) {
  return states.some((state) => state.name === "beta_server" && state.state === "enabled");
}

function getDeployWarning(tab, states) {
  return Boolean(tab && isDeployPage(tab.url) && hasEnabledBetaServer(states));
}

async function getTheme() {
  const { theme = "light" } = await chrome.storage.local.get("theme");
  return THEMES[theme] ? theme : "light";
}

async function getBadgeVisible() {
  const { badgeVisible = true } = await chrome.storage.local.get("badgeVisible");
  return badgeVisible !== false;
}

async function setBadgeVisible(badgeVisible) {
  await chrome.storage.local.set({ badgeVisible });
  const tab = await getActiveTab();

  if (tab && typeof tab.id === "number" && isInspectableUrl(tab.url)) {
    const [states, theme] = await Promise.all([getCookieFlagState(tab), getTheme()]);
    await sendIndicatorState(tab.id, states, theme, badgeVisible, getDeployWarning(tab, states));
  }

  return badgeVisible;
}

async function setTheme(theme) {
  if (!THEMES[theme]) {
    throw new Error("Неизвестная тема оформления.");
  }

  await chrome.storage.local.set({ theme });
  const tab = await getActiveTab();

  if (tab && typeof tab.id === "number") {
    const [states, badgeVisible] = await Promise.all([getCookieFlagState(tab), getBadgeVisible()]);
    await setBadge(tab.id, states, theme, getDeployWarning(tab, states));

    if (isInspectableUrl(tab.url)) {
      await sendIndicatorState(tab.id, states, theme, badgeVisible, getDeployWarning(tab, states));
    }
  }

  return theme;
}

function getUnsupportedStates() {
  return COOKIE_FLAGS.map((flag) => ({
    ...flag,
    value: null,
    state: "unsupported",
    text: `${flag.name}: текущая страница не поддерживает cookie`
  }));
}

async function getCookieFlagState(tab) {
  if (!tab || !isInspectableUrl(tab.url)) {
    return getUnsupportedStates();
  }

  const storeId = await getCookieStoreId(tab);

  return Promise.all(
    COOKIE_FLAGS.map(async (flag) => {
      const cookies = await chrome.cookies.getAll({
        url: tab.url,
        name: flag.name,
        ...(storeId ? { storeId } : {})
      });
      const cookie = cookies[0];
      const value = cookie?.value ?? null;

      if (value === ENABLED_VALUE) {
        return {
          ...flag,
          value,
          state: "enabled",
          text: flag.label,
          cookieText: `${flag.name}=1`
        };
      }

      if (value === DISABLED_VALUE) {
        return {
          ...flag,
          value,
          state: "disabled",
          text: flag.label,
          cookieText: `${flag.name}=0`
        };
      }

      if (value === null) {
        return {
          ...flag,
          value,
          state: "missing",
          text: "cookie не задана",
          cookieText: `${flag.name}=не задана`
        };
      }

      return {
        ...flag,
        value,
        state: "unexpected",
        text: "неизвестное значение, ожидается 1 или 0",
        cookieText: `${flag.name}=${value}`
      };
    })
  );
}

function getEnabledCount(states) {
  return states.filter((state) => state.state === "enabled").length;
}

async function setBadge(tabId, states, theme, deployWarning) {
  const enabledCount = getEnabledCount(states);
  const palette = THEMES[theme] || THEMES.light;

  await chrome.action.setBadgeBackgroundColor({
    tabId,
    color: deployWarning
      ? palette.warningActionBadgeColor
      : enabledCount > 0
        ? palette.actionBadgeColor
        : palette.inactiveActionBadgeColor
  });

  await chrome.action.setBadgeText({
    tabId,
    text: deployWarning ? "BETA!" : enabledCount > 0 ? `${enabledCount}/3` : ""
  });

  await chrome.action.setTitle({
    tabId,
    title: deployWarning
      ? `ВНИМАНИЕ: beta_server=1 на странице деплоя\n${states.map((state) => state.text).join("\n")}`
      : states.map((state) => state.text).join("\n")
  });
}

async function sendIndicatorState(tabId, states, theme, visible, deployWarning) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "FEATURE_COOKIE_STATE",
      states,
      theme,
      visible,
      deployWarning
    });
  } catch {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content-indicator.js"]
      });

      await chrome.tabs.sendMessage(tabId, {
        type: "FEATURE_COOKIE_STATE",
        states,
        theme,
        visible,
        deployWarning
      });
    } catch {
      // Some browser pages and extension pages do not allow script injection.
    }
  }
}

async function updateTab(tab) {
  if (!tab || typeof tab.id !== "number") {
    return [];
  }

  const [states, theme, badgeVisible] = await Promise.all([
    getCookieFlagState(tab),
    getTheme(),
    getBadgeVisible()
  ]);
  const deployWarning = getDeployWarning(tab, states);
  await setBadge(tab.id, states, theme, deployWarning);

  if (isInspectableUrl(tab.url)) {
    await sendIndicatorState(tab.id, states, theme, badgeVisible, deployWarning);
  }

  return states;
}

async function updateActiveTab() {
  const tab = await getActiveTab();
  return updateTab(tab);
}

async function setFeatureCookie(name, enabled) {
  const tab = await getActiveTab();

  if (!tab || !isInspectableUrl(tab.url)) {
    throw new Error("Текущая страница не поддерживает изменение cookie.");
  }

  if (!COOKIE_FLAGS.some((flag) => flag.name === name)) {
    throw new Error(`Cookie ${name} не отслеживается расширением.`);
  }

  const storeId = await getCookieStoreId(tab);

  await chrome.cookies.set({
    url: tab.url,
    name,
    value: enabled ? ENABLED_VALUE : DISABLED_VALUE,
    path: "/",
    ...(storeId ? { storeId } : {})
  });

  return getCookieFlagState(tab);
}

async function getPopupState() {
  const tab = await getActiveTab();
  const [states, theme, badgeVisible] = await Promise.all([
    getCookieFlagState(tab),
    getTheme(),
    getBadgeVisible()
  ]);
  return { states, theme, badgeVisible };
}

chrome.runtime.onInstalled.addListener(updateActiveTab);
chrome.runtime.onStartup.addListener(updateActiveTab);

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId);
  await updateTab(tab);
});

chrome.tabs.onUpdated.addListener(async (_tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    await updateTab(tab);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_FEATURE_COOKIE_STATES") {
    getPopupState()
      .then((state) => sendResponse({ ok: true, ...state }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "SET_FEATURE_COOKIE") {
    setFeatureCookie(message.name, Boolean(message.enabled))
      .then((states) => sendResponse({ ok: true, states }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "SET_THEME") {
    setTheme(message.theme)
      .then((theme) => sendResponse({ ok: true, theme }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "SET_BADGE_VISIBILITY") {
    setBadgeVisible(Boolean(message.visible))
      .then((badgeVisible) => sendResponse({ ok: true, badgeVisible }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return false;
});
