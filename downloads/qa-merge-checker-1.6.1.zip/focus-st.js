// Executed in the isolated world of the ST project tab.
function readStOwnerGroups(account, project, checkOnly = false) {
  if (location.origin !== 'https://cloud.roistat.com' || location.pathname !== '/admin/support/tools/project/' + project) {
    return {error: 'Карточка недоступна. Проверьте вход и права в ST.'};
  }
  function label(root, caption) {
    return Array.from(root.querySelectorAll('.row > .col-md-4')).find(node =>
      node.textContent.trim().replace(/:$/, '').toLowerCase() === caption);
  }
  const ownerLabel = label(document, 'id владельца');
  const owner = ownerLabel?.nextElementSibling?.textContent.trim();
  if (checkOnly) return owner === account;
  if (!owner || !/^\d+$/.test(owner)) return {error: 'ST не показал ID владельца. Проверьте доступ к карточке проекта.'};
  if (owner !== account) return {needProject: true, error: 'В ST у этого проекта другой владелец. Укажите проект выбранного аккаунта.'};
  const panel = ownerLabel.closest('.panel-body');
  const raw = panel && label(panel, 'фокус группы аккаунта')?.nextElementSibling?.textContent.trim();
  if (typeof raw !== 'string') return {error: 'В карточке ST не найдено поле «Фокус группы аккаунта».'};
  if (!raw || /^(?:нет|отсутствуют|—|–|-)$/i.test(raw)) return {groups: []};
  const names = raw.split(',').map(name => name.trim()).filter(Boolean);
  if (!names.every(name => /^[\w.-]+$/.test(name))) return {error: 'Не удалось разобрать названия ФГ в карточке ST.'};
  return {groups: [...new Set(names)]};
}

async function lookupSt(account, suppliedProject) {
  const key = 'fg.st.project.' + account;
  let project = suppliedProject || (await chrome.storage.local.get(key))[key];
  if (!project) {
    const open = await chrome.tabs.query({url: 'https://cloud.roistat.com/admin/support/tools/project/*', currentWindow: true});
    for (const candidate of open) {
      const id = new URL(candidate.url).pathname.match(/^\/admin\/support\/tools\/project\/(\d+)$/)?.[1];
      if (!id) continue;
      const [frame] = await chrome.scripting.executeScript({
        target: {tabId: candidate.id}, func: readStOwnerGroups, args: [account, id, true]
      }).catch(() => []);
      if (frame?.result === true) { project = id; break; }
    }
  }
  if (!project || !/^\d+$/.test(project)) {
    return {needProject: true, error: 'Открытая карточка этого владельца не найдена. Укажите ID одного проекта для первого запроса.'};
  }
  const url = 'https://cloud.roistat.com/admin/support/tools/project/' + project + '?params=';
  const tab = await chrome.tabs.create({url, active: false});
  try {
    const deadline = Date.now() + 35000;
    while (Date.now() < deadline) {
      const info = await chrome.tabs.get(tab.id);
      if (info.status === 'complete' && info.url && info.url !== 'about:blank') {
        if (info.url !== url && info.url !== url.split('?')[0]) return {error: 'ST перенаправил на другую страницу. Проверьте вход и доступ к проекту.'};
        const [frame] = await chrome.scripting.executeScript({
          target: {tabId: tab.id}, func: readStOwnerGroups, args: [account, project]
        });
        const result = frame?.result;
        if (!Array.isArray(result?.groups)) return result || {error: 'Не удалось прочитать карточку ST.'};
        await chrome.storage.local.set({[key]: project});
        return {...result, project};
      }
      await new Promise(resolve => setTimeout(resolve, 350));
    }
    return {error: 'Карточка ST не успела загрузиться. Попробуйте позже.'};
  } finally {
    await chrome.tabs.remove(tab.id).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'fg:st' || sender.frameId !== 0 || !sender.tab || !sender.url) return;
  const url = new URL(sender.url);
  if (url.origin !== 'https://lidia932.github.io' || url.pathname !== '/qa-workbench-pages/focus-groups.html') return;
  if (typeof message.account !== 'string' || !/^\d+$/.test(message.account) ||
      typeof message.project !== 'string' || !/^\d*$/.test(message.project)) {
    reply({error: 'ID аккаунта и проекта указываются цифрами.'});
    return;
  }
  lookupSt(message.account, message.project).then(reply, () => reply({error: 'Не удалось открыть карточку. Проверьте доступ к ST в этом профиле Chrome.'}));
  return true;
});
