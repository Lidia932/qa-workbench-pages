(() => {
  if (window !== window.top || location.pathname !== '/qa-workbench-pages/standup.html') return;
  const button = document.querySelector('#load-post');
  if (!button) return;
  button.dataset.ready = 'true';
  button.addEventListener('click', async event => {
    if (!event.isTrusted || !navigator.userActivation.isActive) return;
    const input = document.querySelector('#platrum-url');
    let result;
    try {
      const url = new URL(input.value.trim());
      const id = url.pathname.match(/^\/(?:[\w.-]+\/)?pl\/([a-z0-9]{26})\/?$/)?.[1];
      if (url.origin !== 'https://roistat.chat.platrum.ru' || !id) throw new Error('Нужна ссылка на сообщение Platrum с /pl/.');
      button.disabled = true;
      result = await chrome.runtime.sendMessage({type: 'standup:post', id});
    } catch (error) {
      result = {error: error.message};
    } finally {
      button.disabled = false;
    }
    button.dispatchEvent(new CustomEvent('qa-standup-result', {detail: JSON.stringify(result || {error: 'Нет ответа от расширения.'})}));
  });
  const send = document.querySelector('#send-standup');
  if (!send) return;
  send.dataset.ready = 'true';
  document.querySelector('#send-standup-help').hidden = true;
  let pending = false;
  let lastText;
  let lastPost;
  let lastDay;
  send.addEventListener('click', async event => {
    if (!event.isTrusted || !navigator.userActivation.isActive || pending) return;
    const text = document.querySelector('#message-text').value;
    if (!text.trim()) return;
    const day = new Date().toDateString();
    let result;
    if (text === lastText && day === lastDay) {
      result = {id: lastPost};
    } else {
      pending = true;
      send.disabled = true;
      try {
        result = await chrome.runtime.sendMessage({type: 'standup:send', text});
        if (result?.id) { lastText = text; lastDay = day; lastPost = result.id; }
      } catch {
        result = null;
      } finally {
        pending = false;
        send.disabled = false;
      }
    }
    send.dispatchEvent(new CustomEvent('qa-standup-sent', {
      detail: JSON.stringify(result || {error: 'Нет ответа от расширения. Проверьте qa-standup перед повторной отправкой.'})
    }));
  });
})();
