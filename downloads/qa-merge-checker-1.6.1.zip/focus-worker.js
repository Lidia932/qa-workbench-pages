const focusOperations = new Set([
  'add_user_to_focus_group', 'remove_user_from_focus_group',
  'add_project_to_marketplace_focus_group', 'remove_project_from_marketplace_focus_group',
  'remove_all_users_from_focus_groups', 'show_user_focus_groups', 'show_project_marketplace_focus_groups',
  'get_users_with_focus_group', 'get_users_without_focus_group_by_visits',
  'get_users_with_active_channel_without_focus_group', 'get_projects_by_users', 'get_projects_with_integration',
  'get_projects_with_marketplace_focus_group', 'add_users_to_focus_group_for_test',
  'add_projects_to_marketplace_focus_group_for_test', 'remove_all_project_from_marketplace_focus_group',
  'send_sms', 'help'
]);
const activeFocusCommands = new Set();
const chatOrigin = 'https://roistat.chat.platrum.ru';
const channelPath = '/api/v4/teams/name/c9d2f3fa6bb6d63bbd9f589250d36698/channels/name/';

const options = {credentials: 'include', redirect: 'error', cache: 'no-store'};
async function getChatChannel(name) {
  const lookup = await fetch(chatOrigin + channelPath + name, {...options, signal: AbortSignal.timeout(12000)});
  if (!lookup.ok) throw new Error('Канал ' + name + ' недоступен. Проверьте вход в Platrum и доступ к каналу.');
  const channel = await lookup.json();
  if (channel.name !== name || !/^[a-z0-9]{26}$/.test(channel.id) || channel.delete_at) {
    throw new Error('Не удалось определить канал ' + name + '.');
  }
  return channel;
}
async function chatPostHeaders() {
  const headers = {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'};
  const csrf = await chrome.cookies.get({url: chatOrigin, name: 'MMCSRF'});
  if (csrf) headers['X-CSRF-Token'] = csrf.value;
  return headers;
}
async function sendFocusCommand(command, channel) {
  const headers = await chatPostHeaders();
  let response;
  try {
    response = await fetch(chatOrigin + '/api/v4/commands/execute', {
      ...options, method: 'POST', headers, signal: AbortSignal.timeout(20000),
      body: JSON.stringify({channel_id: channel.id, team_id: channel.team_id, command})
    });
  } catch {
    throw new Error('Ответ от Platrum не получен. Проверьте канал перед повторной отправкой.');
  }
  if (response.status === 401 || response.status === 403) throw new Error('Проверьте вход в Platrum и права на команду.');
  if (!response.ok) throw new Error('Platrum вернул HTTP ' + response.status + '. Проверьте канал перед повторной отправкой.');
  // A login page or a proxy response is not a slash-command acknowledgement.
  const result = await response.json().catch(() => null);
  if (!result || typeof result !== 'object' || Array.isArray(result) || result.error) {
    throw new Error('Platrum не подтвердил команду. Проверьте канал перед повторной отправкой.');
  }
  return result;
}

function parseAccountGroups(text) {
  if (typeof text !== 'string') return null;
  const plain = text.replaceAll('`', '').trim();
  if (/пользователь[^\n]*не найден/i.test(plain)) throw new Error('ERP не нашёл аккаунт с таким ID.');
  if (/^(?:У пользователя[^\n]* нет фокус[ -]групп|Фокус[ -]группы пользователя[^:\n]* отсутствуют)\.?$/im.test(plain)) return [];
  const match = plain.match(/^Фокус[ -]группы пользователя[^:\n]*:\s*([\s\S]*)$/im);
  if (!match) return null;
  const list = match[1].trim();
  if (!list || /^(?:нет|отсутствуют|—|-)\.?$/i.test(list)) return [];
  const names = list.split(',').map(name => name.trim());
  if (!names.every(name => /^[\w.-]+$/.test(name))) throw new Error('ERP вернул список в неизвестном формате. Проверьте ответ в tools-product.');
  return [...new Set(names)];
}
async function readChat(path) {
  const response = await fetch(chatOrigin + path, {...options, signal: AbortSignal.timeout(6000)});
  if (!response.ok) throw new Error('Не удалось прочитать ответ в tools-product. Проверьте вход в Platrum и доступ к каналу.');
  return response.json();
}
async function lookupAccount(account, channel) {
  const command = 'show_user_focus_groups ' + account;
  const postsPath = '/api/v4/channels/' + channel.id + '/posts';
  const [me, before] = await Promise.all([readChat('/api/v4/users/me'), readChat(postsPath + '?page=0&per_page=1')]);
  const lastId = before.order[0];
  const result = await sendFocusCommand('/erp ' + command, channel);
  const direct = parseAccountGroups(result.text);
  if (direct !== null) return direct;
  const query = lastId ? '?after=' + encodeURIComponent(lastId) + '&per_page=100' : '?page=0&per_page=100';
  for (let attempt = 0; attempt < 10; attempt++) {
    if (attempt) await new Promise(resolve => setTimeout(resolve, 1000));
    const page = await readChat(postsPath + query);
    for (const id of page.order) {
      const post = page.posts[id];
      if (!post || post.delete_at || post.channel_id !== channel.id) continue;
      const parts = post.message.split('```');
      if (parts[1]?.trim() !== command || !parts[2]?.includes('Результат')) continue;
      const author = parts[0].match(/\[\s*@([\w.-]+)\s*\]/);
      if (post.user_id !== me.id && author?.[1] !== me.username) continue;
      const groups = parseAccountGroups(parts[3]);
      if (groups !== null) return groups;
    }
  }
  throw new Error('Команда отправлена, но список ФГ пока не получен. Проверьте ответ в tools-product.');
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['fg:send', 'fg:lookup'].includes(message?.type) || sender.frameId !== 0 || !sender.tab || !sender.url) return;
  const page = new URL(sender.url);
  if (page.origin !== 'https://lidia932.github.io' || page.pathname !== '/qa-workbench-pages/focus-groups.html') return;
  const lookup = message.type === 'fg:lookup';
  if (lookup && (typeof message.account !== 'string' || !/^\d+$/.test(message.account))) {
    reply({error: 'Введите ID аккаунта цифрами.'}); return;
  }
  const command = lookup ? '/erp show_user_focus_groups ' + message.account : message.command;
  if (typeof command !== 'string' || /[\r\n\u0000]/.test(command) || !command.startsWith('/erp ') ||
      !focusOperations.has(command.split(' ')[1])) {
    reply({error: 'Выберите команду ФГ из списка.'});
    return;
  }
  if (activeFocusCommands.has(command)) {
    reply({error: 'Эта команда уже отправляется.'});
    return;
  }
  activeFocusCommands.add(command);
  getChatChannel('tools-product').then(async channel => {
    if (lookup) return {groups: await lookupAccount(message.account, channel)};
    await sendFocusCommand(command, channel);
    return {ok: true};
  }).then(reply, error => reply({error: error.message}))
    .finally(() => activeFocusCommands.delete(command));
  return true;
});
