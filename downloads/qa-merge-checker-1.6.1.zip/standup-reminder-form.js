(() => {
  if (window !== window.top || location.pathname !== '/qa-workbench-pages/standup.html') return;
  const panel = document.querySelector('#standup-reminder');
  if (!panel) return;
  const form = panel.querySelector('form');
  const fields = form.elements;
  const status = panel.querySelector('[role=status]');
  const bell = panel.querySelector('summary');
  let savedSettings;
  let loading = false;
  function display(settings) {
    fields.enabled.checked = settings.enabled;
    fields.time.value = settings.time;
    fields.zone.value = settings.zone;
    fields.text.value = settings.text;
    bell.dataset.enabled = String(settings.enabled);
    bell.title = settings.enabled ? 'Напоминание включено · ' + settings.time : 'Настроить напоминание';
  }
  async function load() {
    if (loading) return;
    loading = true;
    try {
      const result = await chrome.runtime.sendMessage({type: 'standup:reminder-read'});
      if (!result?.settings) throw new Error(result?.error);
      savedSettings = result.settings;
      display(savedSettings);
      panel.querySelector('.reminder-help').hidden = true;
      form.hidden = false;
    } catch { status.textContent = 'Не удалось загрузить настройки. Обновите вкладку и попробуйте ещё раз.'; }
    finally { loading = false; }
  }
  load();
  const preview = fields.namedItem('preview');
  if (preview) {
    preview.disabled = false;
    form.querySelector('.preview-help').hidden = true;
    preview.addEventListener('click', async event => {
      if (!event.isTrusted || !navigator.userActivation.isActive || preview.disabled) return;
      preview.disabled = true;
      try {
        const result = await chrome.runtime.sendMessage({type: 'standup:reminder-preview', text: fields.text.value});
        if (!result?.ok) throw new Error(result?.error || 'Расширение не ответило. Обновите вкладку.');
        status.textContent = 'Проверочное уведомление отправлено.';
      } catch (error) { status.textContent = error.message; }
      finally { preview.disabled = false; }
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.standupReminder?.newValue) return;
    savedSettings = changes.standupReminder.newValue;
    if (!panel.open) display(savedSettings);
  });
  panel.addEventListener('toggle', () => {
    status.textContent = '';
    if (!panel.open && savedSettings) display(savedSettings);
    if (panel.open && form.hidden) load();
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!event.isTrusted || !navigator.userActivation.isActive || fields.save.disabled) return;
    fields.save.disabled = true;
    try {
      const settings = {enabled: fields.enabled.checked, time: fields.time.value, zone: fields.zone.value, text: fields.text.value};
      const result = await chrome.runtime.sendMessage({type: 'standup:reminder-save', settings});
      if (!result?.settings) throw new Error(result?.error || 'Расширение не ответило. Обновите вкладку.');
      display(result.settings);
      status.textContent = settings.enabled ? 'Напоминание сохранено для этого профиля.' : 'Напоминание выключено.';
    } catch (error) { status.textContent = error.message; }
    finally { fields.save.disabled = false; }
  });
})();
