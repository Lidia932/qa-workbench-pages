(() => {
  if (window !== window.top || location.pathname !== '/qa-workbench-pages/focus-groups.html') return;
  const button = document.querySelector('#send-command');
  const form = document.querySelector('#builder');
  if (!button || !form) return;
  button.dataset.ready = 'true';
  document.querySelector('#send-help').hidden = true;
  const lookup = document.querySelector('#lookup-button');
  const stButton = document.querySelector('#st-button');
  if (lookup) {
    lookup.dataset.ready = 'true';
    document.querySelector('#lookup-help').hidden = true;
    let loading = false;
    if (stButton) {
      stButton.dataset.ready = 'true';
      document.querySelector('#st-help').hidden = true;
    }
    async function requestGroups(event) {
      event.preventDefault();
      const st = event.currentTarget === stButton;
      if (!event.isTrusted || !navigator.userActivation.isActive || loading || !lookup.form.reportValidity()) return;
      const account = document.querySelector('#lookup-id').value;
      if (!/^\d+$/.test(account)) return;
      const project = st ? document.querySelector('#st-project').value.trim() : '';
      loading = true;
      lookup.dispatchEvent(new CustomEvent('fg-lookup-start', {detail: st ? 'st' : 'chat'}));
      let result;
      try {
        result = await chrome.runtime.sendMessage(st ? {type: 'fg:st', account, project} : {type: 'fg:lookup', account});
        if (!result) throw new Error();
      } catch {
        result = {error: st ? 'Нет ответа от расширения при чтении ST.' : 'Нет ответа от расширения. Проверьте tools-product перед повторным запросом.'};
      } finally { loading = false; }
      lookup.dispatchEvent(new CustomEvent('fg-lookup-result', {detail: JSON.stringify({...result, account})}));
    }
    lookup.addEventListener('click', requestGroups);
    stButton?.addEventListener('click', requestGroups);
  }
  let pending = false;
  button.addEventListener('click', async event => {
    if (!event.isTrusted || !navigator.userActivation.isActive || pending || button.disabled) return;
    const values = Array.from(form.querySelectorAll('#arguments input'), input => input.value.trim());
    if (!form.reportValidity() || values.some(value => !value)) return;
    const command = ['/erp', form.querySelector('#operation').value, ...values].join(' ');
    if (command !== document.querySelector('#preview').value) return;
    pending = true;
    button.dispatchEvent(new Event('fg-sending'));
    let result;
    try {
      result = await chrome.runtime.sendMessage({type: 'fg:send', command});
      if (!result) throw new Error();
    } catch {
      result = {error: 'Нет ответа от расширения. Проверьте tools-product перед повторной отправкой.'};
    } finally { pending = false; }
    button.dispatchEvent(new CustomEvent('fg-result', {detail: JSON.stringify({...result, command})}));
  });
})();
