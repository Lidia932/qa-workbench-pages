(() => {
if (globalThis.__qaMergeCheckerLoaded) {
  return;
}

globalThis.__qaMergeCheckerLoaded = true;

const DEFAULT_EXCLUDED_DEVELOPERS = [
  'Александр Чибрикин',
  'Чибрикин Александр',
  'Александра Чибрикина',
  'Чибрикина Александра',
  'Лидия Алексеева',
  'Алексеева Лидия',
  'Лидию Алексееву',
  'Алексееву Лидию',
  'Юрий Суханов',
  'Суханов Юрий',
  'Юрия Суханова',
  'Суханова Юрия'
];

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function getElementText(element) {
  if (!element) return '';
  return normalizeText([element.textContent, element.innerText].filter(Boolean).join(' '));
}

function normalizeName(value) {
  return normalizeText(value)
    .replace(/^@+/, '')
    .toLowerCase();
}

function isExcludedDeveloper(name) {
  const normalized = normalizeName(name);
  return DEFAULT_EXCLUDED_DEVELOPERS.some(excluded => normalizeName(excluded) === normalized);
}

function normalizePrUrl(url) {
  if (!url) return null;

  try {
    const parsed = new URL(url, location.href);
    const match = parsed.pathname.match(/^(.*?\/pull-requests\/\d+)/i);
    if (!match) return null;
    return `${parsed.origin}${match[1]}`;
  } catch {
    const match = String(url).match(/https?:\/\/\S*?\/pull-requests\/\d+/i);
    return match ? match[0] : null;
  }
}

function extractPrUrl(containerText, container) {
  const fromText = containerText.match(/https?:\/\/\S*?\/pull-requests\/\d+(?:\/overview)?/i)?.[0];
  const fromLink = container?.querySelector?.('a[href*="pull-requests"]')?.href;
  const normalized = normalizePrUrl(fromText || fromLink);
  if (normalized) return normalized;

  const prNumber = containerText.match(/\bPull request\s*#?(\d+)\b/i)?.[1] ||
    containerText.match(/\bPR\s*#?(\d+)\b/i)?.[1];
  return prNumber ? `pull-request:${prNumber}` : null;
}

function extractPrUrls(containerText, container) {
  const urls = new Set();
  const text = String(containerText || '');

  for (const link of container?.querySelectorAll?.('a[href*="pull-requests"]') || []) {
    const normalized = normalizePrUrl(link.href);
    if (normalized) urls.add(normalized);
  }

  for (const match of text.matchAll(/https?:\/\/\S*?\/pull-requests\/\d+(?:\/overview)?/gi)) {
    const normalized = normalizePrUrl(match[0]);
    if (normalized) urls.add(normalized);
  }

  for (const match of text.matchAll(/\bPull request\s*#?(\d+)\b/gi)) {
    urls.add(`pull-request:${match[1]}`);
  }

  for (const match of text.matchAll(/\bPR\s*#?(\d+)\b/gi)) {
    urls.add(`pull-request:${match[1]}`);
  }

  return [...urls];
}

function pullRequestKey(url) {
  return String(url || '').match(/\/pull-requests\/(\d+)/i)?.[1] ||
    String(url || '').match(/^pull-request:(\d+)$/i)?.[1] ||
    String(url || '').match(/\bPull request\s*#?(\d+)\b/i)?.[1] ||
    String(url || '').match(/\bPR\s*#?(\d+)\b/i)?.[1] ||
    null;
}

function extractDeveloper(text) {
  const normalized = normalizeText(text);
  return (
    normalized.match(/пользовател[ье]м\s+(@?[a-z0-9._-]+)/i)?.[1] ||
    normalized.match(/пользовател[ье]м\s+(@?[А-ЯЁ][а-яё]+(?:\s+[А-ЯЁ][а-яё]+)+)/i)?.[1] ||
    normalized.match(/developer\s*[:：]\s*(@?[a-z0-9._-]+)/i)?.[1] ||
    normalized.match(/developer\s*[:：]\s*(@?[А-ЯЁ][а-яё]+(?:\s+[А-ЯЁ][а-яё]+)+)/i)?.[1] ||
    normalized.match(/разработчик\s*[:：]\s*(@?[a-z0-9._-]+)/i)?.[1] ||
    normalized.match(/разработчик\s*[:：]\s*(@?[А-ЯЁ][а-яё]+(?:\s+[А-ЯЁ][а-яё]+)+)/i)?.[1] ||
    null
  );
}

function textHasRelativeTime(text) {
  return /секунд[уы]?\s+назад|seconds?\s+назад|минут[уы]?\s+назад|minutes?\s+назад|мин\.\s+назад|час(?:а|ов)?\s+назад|hours?\s+назад|только что|меньше минуты назад/i.test(text);
}

function parseUtcTitleMinutesAgo(element) {
  const titledElement = element.closest('[title*="UTC"]') || element.querySelector?.('[title*="UTC"]');
  const title = normalizeText(titledElement?.getAttribute('title'));
  const match = title.match(/(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})(?::(\d{2}))?\s+UTC/i);

  if (!match) return null;

  const [, year, month, day, hour, minute, second = '0'] = match;
  const utcTime = Date.UTC(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour),
    Number(minute),
    Number(second)
  );

  return Math.max(0, Math.floor((Date.now() - utcTime) / 60000));
}

function parseMinutesAgo(text, element) {
  const normalized = normalizeText(text);
  if (/только что|меньше минуты назад/i.test(normalized)) return 0;
  if (/(\d+)\s+(?:секунд[уы]?|seconds?)\s+назад/i.test(normalized)) return 0;

  const minutes = normalized.match(/(\d+)\s+(?:минут[уы]?|minutes?|мин\.)\s+назад/i)?.[1];
  if (minutes) return Number(minutes);

  const hours = normalized.match(/(\d+)\s+(?:час(?:а|ов)?|hours?)\s+назад/i)?.[1];
  if (hours) return Number(hours) * 60;

  if (/\bчас\s+назад/i.test(normalized)) return 60;

  const minutesFromUtcTitle = element ? parseUtcTitleMinutesAgo(element) : null;
  if (minutesFromUtcTitle !== null) return minutesFromUtcTitle;

  return null;
}

function findUsefulContainer(element) {
  return (
    element.closest('tr, li, article, .aui-item, .activity-item, .commit, .event, [data-testid*="post"]') ||
    element.parentElement ||
    element
  );
}

function findDeployResultElement(deploy) {
  return deploy.querySelector('.js-deploy-result') ||
    deploy.nextElementSibling?.matches?.('.js-deploy-result') && deploy.nextElementSibling ||
    deploy.parentElement?.querySelector?.('.js-deploy-result') ||
    deploy;
}

function addDeployPr(resultByUrl, url, developer, minutesAgo) {
  if (!url || isExcludedDeveloper(developer)) return;

  const resultKey = pullRequestKey(url) || url;
  if (!resultByUrl.has(resultKey)) {
    resultByUrl.set(resultKey, {
      url,
      developer: normalizeText(developer).replace(/^@+/, ''),
      minutesAgo
    });
  }
}

function parseDeployBlocks(resultByUrl, stats, windowMinutes) {
  for (const deploy of document.querySelectorAll('.js-deploy')) {
    const action = deploy.querySelector('.js-action-collapse') || deploy;
    const actionText = getElementText(action);
    if (!actionText || !/\bmerge\b|смерж/i.test(actionText)) {
      continue;
    }

    stats.mergeMentions += 1;

    const minutesAgo = parseMinutesAgo(actionText, action);
    if (minutesAgo === null || minutesAgo > windowMinutes) continue;

    stats.recentMergeMentions += 1;

    const result = findDeployResultElement(deploy);
    const details = normalizeText([getElementText(result), getElementText(deploy)].join(' '));
    const developer = extractDeveloper(actionText) || extractDeveloper(details) || 'Не указан';

    for (const url of extractPrUrls(details, result)) {
      addDeployPr(resultByUrl, url, developer, minutesAgo);
    }
  }
}

function parseDeployPage(windowMinutes) {
  const resultByUrl = new Map();
  const stats = {
    pullRequestLinks: document.querySelectorAll('a[href*="pull-requests"]').length,
    mergeMentions: 0,
    recentMergeMentions: 0
  };

  parseDeployBlocks(resultByUrl, stats, windowMinutes);
  if (resultByUrl.size) {
    return {
      prs: [...resultByUrl.values()].sort((a, b) => a.minutesAgo - b.minutesAgo),
      stats
    };
  }

  const elements = [...document.querySelectorAll('body *')];
  for (const element of elements) {
    if (element.closest('.js-deploy') || element.querySelector('.js-deploy')) {
      continue;
    }

    const elementText = normalizeText(element.innerText);
    if (!elementText || !/\bmerge\b|смерж/i.test(elementText)) {
      continue;
    }

    stats.mergeMentions += 1;

    if (!textHasRelativeTime(elementText)) {
      continue;
    }

    const minutesAgo = parseMinutesAgo(elementText, element);
    if (minutesAgo === null || minutesAgo > windowMinutes) continue;

    stats.recentMergeMentions += 1;

    const container = findUsefulContainer(element);
    const details = normalizeText(container.innerText || elementText);
    const url = extractPrUrl(details, container);
    const developer = extractDeveloper(details) || extractDeveloper(elementText) || 'Не указан';

    addDeployPr(resultByUrl, url, developer, minutesAgo);
  }

  return {
    prs: [...resultByUrl.values()].sort((a, b) => a.minutesAgo - b.minutesAgo),
    stats
  };
}

function tableHeaders(table) {
  return [...table.querySelectorAll('thead th, tr:first-child th, tr:first-child td')]
    .map(cell => normalizeText(cell.innerText).toLowerCase());
}

function columnIndex(headers, names) {
  return headers.findIndex(header => names.some(name => header.includes(name)));
}

function getReleaseTableCandidates() {
  const candidates = [];

  for (const table of document.querySelectorAll('table')) {
    const headers = tableHeaders(table);
    const linkIndex = columnIndex(headers, ['ссылка', 'pull request', 'pr']);
    const developerIndex = columnIndex(headers, ['разработчик', 'developer']);
    const responsibleIndex = columnIndex(headers, ['ответственный', 'qa']);

    if (linkIndex === -1 || developerIndex === -1) continue;

    const rect = table.getBoundingClientRect();
    const visibleHeight = Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0);
    const visible = rect.width > 0 && rect.height > 0 && visibleHeight > 0;
    const centerDistance = Math.abs((rect.top + rect.height / 2) - window.innerHeight / 2);

    candidates.push({
      table,
      linkIndex,
      developerIndex,
      responsibleIndex,
      visible,
      centerDistance
    });
  }

  return candidates;
}

function selectCurrentReleaseTable(candidates) {
  const visibleCandidates = candidates.filter(candidate => candidate.visible);

  if (visibleCandidates.length) {
    return visibleCandidates.sort((a, b) => a.centerDistance - b.centerDistance)[0];
  }

  return candidates[candidates.length - 1] || null;
}

function parsePlatrumThread() {
  const rows = [];
  const releaseTable = selectCurrentReleaseTable(getReleaseTableCandidates());

  if (!releaseTable) {
    return rows;
  }

  const {
    table,
    linkIndex,
    developerIndex,
    responsibleIndex
  } = releaseTable;

  const bodyRows = [...table.querySelectorAll('tbody tr')];
  const fallbackRows = [...table.querySelectorAll('tr')].slice(1);

  for (const row of bodyRows.length ? bodyRows : fallbackRows) {
    const cells = [...row.querySelectorAll('td')];
    if (!cells.length) continue;

    const linkCell = cells[linkIndex];
    const developerCell = cells[developerIndex];
    const responsibleCell = responsibleIndex >= 0 ? cells[responsibleIndex] : null;
    const url = normalizePrUrl(linkCell?.querySelector('a')?.href || linkCell?.innerText);
    const developer = normalizeText(developerCell?.innerText).replace(/^@+/, '');
    const responsible = normalizeText(responsibleCell?.innerText).replace(/^@+/, '') || 'Не указан';

    if (!url || !developer || isExcludedDeveloper(developer)) continue;

    rows.push({ url, developer, responsible });
  }

  return [...new Map(rows.map(row => [row.url, row])).values()];
}

function comparePlatrumWithMerged(mergedPrs) {
  const expectedRows = parsePlatrumThread();
  const mergedPrKeys = new Set((mergedPrs || []).map(pr => pullRequestKey(pr.url)).filter(Boolean));
  const expectedPrKeys = new Set(expectedRows.map(row => pullRequestKey(row.url)).filter(Boolean));
  const missing = expectedRows.filter(row => !mergedPrKeys.has(pullRequestKey(row.url)));
  const extra = (mergedPrs || []).filter(pr => !expectedPrKeys.has(pullRequestKey(pr.url)));

  return {
    expected: expectedRows,
    merged: mergedPrs || [],
    missing,
    extra
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.type === 'PARSE_DEPLOY') {
      sendResponse({ ok: true, ...parseDeployPage(message.windowMinutes || 30) });
      return true;
    }

    if (message.type === 'PARSE_PLATRUM') {
      sendResponse({ ok: true, expected: parsePlatrumThread() });
      return true;
    }

    if (message.type === 'COMPARE_PLATRUM') {
      sendResponse({ ok: true, comparison: comparePlatrumWithMerged(message.mergedPrs || []) });
      return true;
    }
  } catch (error) {
    sendResponse({ ok: false, error: error.message });
    return true;
  }
});
})();
