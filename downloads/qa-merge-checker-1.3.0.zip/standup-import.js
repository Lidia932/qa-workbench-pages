(() => {
  if (location.pathname !== '/qa-workbench-pages/standup.html') return;
  const button = document.querySelector('#load-post');
  if (!button) return;
  button.dataset.ready = 'true';
  button.addEventListener('click', async event => {
    if (!event.isTrusted || !navigator.userActivation.isActive) return;
    const input = document.querySelector('#platrum-url');
    let result;
    try {
      const url = new URL(input.value.trim());
      const id = url.pathname.match(/^\/(?:[\w.-]+\/)?pl\/([a-z0-9]{26})\/?$/)?.[1];
      if (url.origin !== 'https://roistat.chat.platrum.ru' || !id) throw new Error('Нужна ссылка на сообщение Platrum с /pl/.');
      button.disabled = true;
      result = await chrome.runtime.sendMessage({type: 'standup:post', id});
    } catch (error) {
      result = {error: error.message};
    } finally {
      button.disabled = false;
    }
    button.dispatchEvent(new CustomEvent('qa-standup-result', {detail: JSON.stringify(result || {error: 'Нет ответа от расширения.'})}));
  });
})();
