(() => {
  const BASE_URL = 'https://roistat.chat.platrum.ru';
  const TEAM_PATH = 'c9d2f3fa6bb6d63bbd9f589250d36698';
  const CHANNEL_ID = 'q8me8oz6ifr8djgp6txm4wzm1w';
  const RELEASE_SHEET_ID = '1dFTb3UgsfQG35SZR0v2xmL_ytcI_7LQiUWknua9CBuU';
  const RELEASE_SHEET_GID = '0';
  const RELEASE_STATS_TSV_COLUMN_COUNT = 12;
  const RELEASE_STATS_YEAR = 2026;
  const RELEASE_RESPONSIBLES_BY_USERNAME = {
    'sukhanov.yu': '@sukhanov.yu',
    'chibrikin.a': '@chibrikin.a',
    'smirnova.ksu': '@smirnova.ksu',
    'alekseeva.li': '@alekseeva.li'
  };
  const RELEASE_THREAD_MESSAGE = 'Пойдет в релиз';
  const RELEASE_START_RE = /начина(?:ем|ло)\s+релиз/i;
  const HOLIDAY_API_BASE_URL = 'https://calendar.kuzyak.in/api/calendar';
  const STATIC_NON_WORKING_DAYS_BY_YEAR = {
    2026: [
      '2026-01-01',
      '2026-01-02',
      '2026-01-03',
      '2026-01-04',
      '2026-01-05',
      '2026-01-06',
      '2026-01-07',
      '2026-01-08',
      '2026-02-23',
      '2026-03-09',
      '2026-01-09',
      '2026-05-01',
      '2026-05-11',
      '2026-06-12',
      '2026-11-04',
      '2026-12-31'
    ]
  };
  const cookieCache = new Map();
  const workingDayCache = new Map();
  const holidayCache = new Map();
  const MOSCOW_OFFSET_MS = 3 * 60 * 60 * 1000;
  const PROCESSED_REACTIONS = new Set(['one', 'two', 'hourglass', 'hourglass_flowing_sand', 'white_check_mark']);
  const SERVICE_MARKERS = ['начинаем релиз', 'скоуп релиза'];
  const STASH_RE = /https:\/\/stash\.roistat\.com\/[^\s<>)\]]+/g;

  const FIELD_LABELS = {
    priority: 'Приоритет',
    feature: 'Фича',
    developer: 'Разработчик',
    fg: 'ФГ',
    taskUrl: 'Ссылка на задачу в Platrum',
    description: 'Описание доработки'
  };

  function normalizeText(value) {
    return String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function stripMarkup(value) {
    const cleaned = normalizeText(value).replace(/^\[([^\]]+)\]\([^)]+\)$/, '$1');
    return normalizeText(cleaned.replace(/^`+|`+$/g, ''));
  }

  function normalizePriority(value, blocker = false) {
    const compact = stripMarkup(value);
    const mapped = {
      'квартальная задача': 'Кварт',
      'кварталка': 'Кварт',
      'кварт': 'Кварт',
      'задача с внешним дедлайном': 'Вн. дедлайн',
      'вн. дедлайн': 'Вн. дедлайн',
      'обычный': ''
    }[compact.toLowerCase()];

    const normalized = mapped === undefined ? compact : mapped;
    return blocker && !normalized ? 'Блокер' : normalized;
  }

  function hasMeaningfulFg(value) {
    const compact = stripMarkup(value);
    return Boolean(compact) && !new Set(['-', 'Нет', 'нет', '—']).has(compact);
  }

  function parseMarkdownFields(message) {
    const fields = {};

    for (const rawLine of String(message || '').split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line.startsWith('**')) continue;

      for (const label of Object.values(FIELD_LABELS)) {
        const safeLabel = escapeRegExp(label);
        const patterns = [
          new RegExp(`^\\*\\*${safeLabel}:\\*\\*\\s*(.*)$`),
          new RegExp(`^\\*\\*${safeLabel}\\?\\*\\*\\s*(.*)$`),
          new RegExp(`^\\*\\*${safeLabel}:\\s*\\*\\*\\s*(.*)$`)
        ];
        const match = patterns.map(pattern => line.match(pattern)).find(Boolean);
        if (match) {
          fields[label] = stripMarkup(match[1]);
          break;
        }
      }
    }

    return fields;
  }

  function parseDevMergeFields(message) {
    const parsed = parseMarkdownFields(message);
    return {
      priority: normalizePriority(parsed[FIELD_LABELS.priority] || ''),
      feature: parsed[FIELD_LABELS.feature] || '',
      developer: parsed[FIELD_LABELS.developer] || '',
      fg: parsed[FIELD_LABELS.fg] || '',
      taskUrl: parsed[FIELD_LABELS.taskUrl] || '',
      description: parsed[FIELD_LABELS.description] || ''
    };
  }

  function normalizeStashUrl(url) {
    const match = String(url || '').match(/https:\/\/stash\.roistat\.com\/projects\/[^\s\])]+\/pull-requests\/\d+\/overview/);
    return (match ? match[0] : String(url || '')).replace(/^[\[\]()<>.,]+|[\[\]()<>.,]+$/g, '');
  }

  function normalizePrUrl(url) {
    if (!url) return null;

    const markdownUrl = String(url).match(/\((https?:\/\/[^)]+\/pull-requests\/\d+(?:\/overview)?)\)/i)?.[1];
    const rawUrl = markdownUrl || String(url).match(/https?:\/\/\S*?\/pull-requests\/\d+(?:\/overview)?/i)?.[0];
    if (!rawUrl) return null;

    try {
      const parsed = new URL(rawUrl);
      const match = parsed.pathname.match(/^(.*?\/pull-requests\/\d+)/i);
      if (!match) return null;
      return `${parsed.origin}${match[1]}`;
    } catch {
      const match = rawUrl.match(/https?:\/\/\S*?\/pull-requests\/\d+/i);
      return match ? match[0] : null;
    }
  }

  function pullRequestKey(url) {
    return String(url || '').match(/\/pull-requests\/(\d+)/i)?.[1] ||
      String(url || '').match(/^pull-request:(\d+)$/i)?.[1] ||
      String(url || '').match(/\bPR\s*#?(\d+)\b/i)?.[1] ||
      String(url || '').match(/\bPull request\s*#?(\d+)\b/i)?.[1] ||
      null;
  }

  function extractStashUrls(message) {
    const urls = [];
    for (const rawUrl of String(message || '').match(STASH_RE) || []) {
      const cleaned = normalizeStashUrl(rawUrl);
      if (cleaned && !urls.includes(cleaned)) urls.push(cleaned);
    }
    return urls;
  }

  function isServicePost(message) {
    const lowered = String(message || '').toLowerCase();
    return SERVICE_MARKERS.some(marker => lowered.includes(marker));
  }

  function moscowParts(ms) {
    const date = new Date(ms + MOSCOW_OFFSET_MS);
    return {
      year: date.getUTCFullYear(),
      month: date.getUTCMonth(),
      day: date.getUTCDate(),
      hours: date.getUTCHours(),
      minutes: date.getUTCMinutes(),
      seconds: date.getUTCSeconds()
    };
  }

  function currentMoscowYear() {
    return moscowParts(Date.now()).year;
  }

  function moscowDateStartMs(parts) {
    return Date.UTC(parts.year, parts.month, parts.day) - MOSCOW_OFFSET_MS;
  }

  function nextWorkday(parts) {
    const date = new Date(Date.UTC(parts.year, parts.month, parts.day + 1));
    while ([0, 6].includes(date.getUTCDay())) {
      date.setUTCDate(date.getUTCDate() + 1);
    }
    return {
      year: date.getUTCFullYear(),
      month: date.getUTCMonth(),
      day: date.getUTCDate()
    };
  }

  function formatDate(parts) {
    return [
      String(parts.day).padStart(2, '0'),
      String(parts.month + 1).padStart(2, '0'),
      String(parts.year)
    ].join('/');
  }

  function effectiveDate(createAtMs) {
    let parts = moscowParts(createAtMs);
    if (
      parts.hours > 18 ||
      (parts.hours === 18 && (parts.minutes > 0 || parts.seconds > 0)) ||
      (parts.hours === 18 && parts.minutes === 0 && parts.seconds === 0)
    ) {
      parts = nextWorkday(parts);
    }
    return formatDate(parts);
  }

  function dateRangeForMode(mode) {
    const todayParts = moscowParts(Date.now());
    const todayStart = moscowDateStartMs(todayParts);
    const start = mode === 'today' ? todayStart : todayStart - 24 * 60 * 60 * 1000;
    const end = todayStart + 24 * 60 * 60 * 1000 - 1;
    return { start, end };
  }

  function parseDateInput(value) {
    const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;

    return {
      year: Number(match[1]),
      month: Number(match[2]) - 1,
      day: Number(match[3])
    };
  }

  function parseSheetDate(value) {
    const compact = normalizeText(value);
    if (!compact) return null;

    let match = compact.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2}|\d{4})$/);
    if (match) {
      const rawYear = Number(match[3]);
      return {
        year: rawYear < 100 ? 2000 + rawYear : rawYear,
        month: Number(match[2]) - 1,
        day: Number(match[1])
      };
    }

    match = compact.match(/^(\d{4})[./-](\d{1,2})[./-](\d{1,2})$/);
    if (!match) return null;

    return {
      year: Number(match[1]),
      month: Number(match[2]) - 1,
      day: Number(match[3])
    };
  }

  function formatShortSheetDate(parts) {
    return [
      String(parts.day).padStart(2, '0'),
      String(parts.month + 1).padStart(2, '0'),
      String(parts.year % 100).padStart(2, '0')
    ].join('.');
  }

  function formatInputDate(parts) {
    return [
      String(parts.day).padStart(2, '0'),
      String(parts.month + 1).padStart(2, '0'),
      String(parts.year).padStart(4, '0')
    ].join('/');
  }

  function formatIsoDate(parts) {
    return [
      String(parts.year).padStart(4, '0'),
      String(parts.month + 1).padStart(2, '0'),
      String(parts.day).padStart(2, '0')
    ].join('-');
  }

  function parseBooleanLike(value) {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value !== 0;
    if (typeof value === 'string') {
      const normalized = value.trim().toLowerCase();
      if (normalized === 'true') return true;
      if (normalized === 'false') return false;
      if (normalized === '1') return true;
      if (normalized === '0') return false;
    }
    return null;
  }

  function officialWorkingDayOverride(parts) {
    if (parts?.year !== 2026) return null;

    const isoDate = formatIsoDate(parts);
    const nonWorkingDates = STATIC_NON_WORKING_DAYS_BY_YEAR[2026] || [];
    if (nonWorkingDates.includes(isoDate)) return false;

    return !isWeekendDate(new Date(Date.UTC(parts.year, parts.month, parts.day)));
  }

  function compareDateParts(left, right) {
    return Date.UTC(left.year, left.month, left.day) - Date.UTC(right.year, right.month, right.day);
  }

  function nextDateParts(parts) {
    const date = new Date(Date.UTC(parts.year, parts.month, parts.day + 1));
    return {
      year: date.getUTCFullYear(),
      month: date.getUTCMonth(),
      day: date.getUTCDate()
    };
  }

  function dateRangeParts(startParts, endParts) {
    const dates = [];
    if (!startParts || !endParts || compareDateParts(startParts, endParts) > 0) return dates;

    let cursor = { ...startParts };
    while (compareDateParts(cursor, endParts) <= 0) {
      dates.push(cursor);
      cursor = nextDateParts(cursor);
    }

    return dates;
  }

  async function fetchWorkingDayInfo(parts) {
    const dateKey = formatIsoDate(parts);
    if (workingDayCache.has(dateKey)) return workingDayCache.get(dateKey);

    const officialOverride = officialWorkingDayOverride(parts);
    if (officialOverride !== null) {
      const promise = Promise.resolve(officialOverride);
      workingDayCache.set(dateKey, promise);
      return promise;
    }

    const promise = fetch(`${HOLIDAY_API_BASE_URL}/${parts.year}/${parts.month + 1}/${parts.day}`, {
      credentials: 'omit',
      headers: { Accept: 'application/json' }
    }).then(async response => {
      if (!response.ok) {
        throw new Error(`Holiday API returned ${response.status} for ${dateKey}`);
      }
      const payload = await response.json();
      const directValue = parseBooleanLike(payload?.isWorkingDay);
      if (directValue !== null) return directValue;

      const nestedValue = parseBooleanLike(payload?.day?.isWorkingDay);
      if (nestedValue !== null) return nestedValue;

      const holidayValue = parseBooleanLike(payload?.isHoliday ?? payload?.day?.isHoliday);
      if (holidayValue !== null) return !holidayValue;

      const staticDates = STATIC_NON_WORKING_DAYS_BY_YEAR[parts.year];
      if (staticDates?.includes(dateKey)) return false;
      return null;
    }).catch(() => {
      const staticDates = STATIC_NON_WORKING_DAYS_BY_YEAR[parts.year];
      if (staticDates?.includes(dateKey)) return false;
      return null;
    });

    workingDayCache.set(dateKey, promise);
    return promise;
  }

  async function buildWorkingDayMap(startParts, endParts) {
    const dates = dateRangeParts(startParts, endParts);
    const entries = await Promise.all(
      dates.map(async parts => [formatIsoDate(parts), await fetchWorkingDayInfo(parts)])
    );
    return new Map(entries);
  }

  async function fetchHolidayInfo(year) {
    if (holidayCache.has(year)) return holidayCache.get(year);

    const promise = fetch(`${HOLIDAY_API_BASE_URL}/${year}/holidays`, {
      credentials: 'omit',
      headers: { Accept: 'application/json' }
    }).then(async response => {
      if (!response.ok) {
        throw new Error(`Holiday API returned ${response.status} for ${year}/holidays`);
      }
      const payload = await response.json();
      const holidayDates = new Set(
        (payload?.holidays || [])
          .map(item => normalizeText(item?.date).slice(0, 10))
          .filter(Boolean)
      );
      return holidayDates;
    }).catch(() => {
      const staticDates = STATIC_NON_WORKING_DAYS_BY_YEAR[year];
      return staticDates ? new Set(staticDates) : null;
    });

    holidayCache.set(year, promise);
    return promise;
  }

  async function buildHolidayFallbackMap(startParts, endParts) {
    const startYear = startParts?.year;
    const endYear = endParts?.year;
    if (!startYear || !endYear) return new Map();

    const years = [];
    for (let year = startYear; year <= endYear; year += 1) {
      years.push(year);
    }

    const sets = await Promise.all(years.map(year => fetchHolidayInfo(year)));
    const result = new Map();

    years.forEach((year, index) => {
      result.set(year, sets[index]);
    });

    return result;
  }

  function formatTimeFromMs(ms) {
    const parts = moscowParts(ms);
    return [
      String(parts.hours).padStart(2, '0'),
      String(parts.minutes).padStart(2, '0')
    ].join(':');
  }

  function parseYearFromCell(value) {
    const compact = normalizeText(value);
    if (!compact) return null;

    let match = compact.match(/\b(\d{1,2})[./-](\d{1,2})[./-](\d{2}|\d{4})\b/);
    if (match) {
      const rawYear = Number(match[3]);
      return rawYear < 100 ? 2000 + rawYear : rawYear;
    }

    match = compact.match(/\b(\d{4})[./-](\d{1,2})[./-](\d{1,2})\b/);
    return match ? Number(match[1]) : null;
  }

  function rowBelongsToCurrentYear(row) {
    return parseYearFromCell(row[1]) === currentMoscowYear();
  }

  function dateRangeForDates(startDate, endDate) {
    const startParts = parseDateInput(startDate);
    const endParts = parseDateInput(endDate);
    if (!startParts || !endParts) return dateRangeForMode('today_yesterday');

    const start = moscowDateStartMs(startParts);
    const end = Date.UTC(endParts.year, endParts.month, endParts.day + 1) - MOSCOW_OFFSET_MS - 1;

    if (start > end) {
      throw new Error('Дата начала не может быть позже даты окончания.');
    }

    return { start, end };
  }

  function getCookie(name, url = BASE_URL) {
    const cacheKey = `${url}:${name}`;
    if (cookieCache.has(cacheKey)) {
      return Promise.resolve(cookieCache.get(cacheKey));
    }

    return new Promise(resolve => {
      if (!globalThis.chrome?.cookies?.get) {
        resolve(null);
        return;
      }

      chrome.cookies.get({ url, name }, cookie => {
        const value = cookie?.value || null;
        cookieCache.set(cacheKey, value);
        resolve(value);
      });
    });
  }

  async function fetchJson(path, options = {}) {
    const headers = {
      Accept: 'application/json',
      ...(options.headers || {})
    };

    if (options.method && options.method !== 'GET') {
      const csrfToken = await getCookie('MMCSRF');
      if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
      headers['Content-Type'] = headers['Content-Type'] || 'application/json';
    }

    const response = await fetch(BASE_URL + path, {
      ...options,
      credentials: 'include',
      headers
    });

    if (!response.ok) {
      throw new Error(`Platrum API вернул ${response.status} для ${path}`);
    }

    const text = await response.text();
    return text ? JSON.parse(text) : null;
  }

  async function postJson(path, payload) {
    return fetchJson(path, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async function deleteJson(path) {
    return fetchJson(path, { method: 'DELETE' });
  }

  async function fetchText(url) {
    const response = await fetch(url, {
      credentials: 'include',
      headers: { Accept: 'text/csv,text/plain,*/*' }
    });

    if (!response.ok) {
      throw new Error(`Google Sheets вернул ${response.status}`);
    }

    const text = await response.text();
    if (/^\s*<!doctype html|<html[\s>]/i.test(text)) {
      throw new Error('Google Sheets вернул HTML вместо CSV. Проверь, что таблица доступна в этом Chrome-профиле.');
    }

    return text;
  }

  function parseCsv(text) {
    const rows = [];
    let row = [];
    let cell = '';
    let quoted = false;

    for (let index = 0; index < String(text || '').length; index += 1) {
      const char = text[index];
      const nextChar = text[index + 1];

      if (quoted) {
        if (char === '"' && nextChar === '"') {
          cell += '"';
          index += 1;
        } else if (char === '"') {
          quoted = false;
        } else {
          cell += char;
        }
        continue;
      }

      if (char === '"') {
        quoted = true;
      } else if (char === ',') {
        row.push(cell);
        cell = '';
      } else if (char === '\n') {
        row.push(cell);
        rows.push(row);
        row = [];
        cell = '';
      } else if (char !== '\r') {
        cell += char;
      }
    }

    row.push(cell);
    if (row.some(value => value !== '') || rows.length) rows.push(row);
    return rows;
  }

  function extractPostId(threadUrl) {
    const match = String(threadUrl || '').match(/\/pl\/([a-z0-9]+)/i);
    return match?.[1] || null;
  }

  async function readReleaseThreadRows(releaseNumber) {
    const normalizedRelease = normalizeText(releaseNumber);
    if (!normalizedRelease) {
      throw new Error('Укажи номер релиза.');
    }

    const url = `https://docs.google.com/spreadsheets/d/${RELEASE_SHEET_ID}/export?format=csv&gid=${RELEASE_SHEET_GID}`;
    const csv = await fetchText(url);
    const rows = parseCsv(csv);
    const matched = [];
    const seenUrls = new Set();

    rows.forEach((row, index) => {
      const rowRelease = normalizeText(row[2]);
      const threadUrl = normalizeText(row[3]);

      if (
        rowRelease !== normalizedRelease ||
        !rowBelongsToCurrentYear(row) ||
        !threadUrl ||
        seenUrls.has(threadUrl)
      ) {
        return;
      }

      seenUrls.add(threadUrl);
      matched.push({
        sheetRowNumber: index + 1,
        release: rowRelease,
        threadUrl
      });
    });

    return matched;
  }

  function normalizedHeader(value) {
    return normalizeText(value).toLowerCase();
  }

  function headerIndex(headers, names) {
    const normalizedHeaders = headers.map(normalizedHeader);
    const normalizedNames = names.map(normalizedHeader);
    const exactIndex = normalizedHeaders.findIndex(header => normalizedNames.includes(header));
    if (exactIndex !== -1) return exactIndex;
    return normalizedHeaders.findIndex(header => normalizedNames.some(name => header.includes(name)));
  }

  function releaseNumberFromName(value) {
    const release = normalizeReleaseName(value);
    return release.match(/\/\s*(\d+)\s*$/)?.[1] || null;
  }

  function normalizeReleaseName(value) {
    const release = normalizeText(value);
    const match = release.match(/^(\d{1,2})[.-](\d{1,2})\/0*(\d+)$/);
    if (!match) return release;

    const day = String(Number(match[1])).padStart(2, '0');
    const month = String(Number(match[2])).padStart(2, '0');
    const releaseNumber = String(Number(match[3]));
    return `${day}-${month}/${releaseNumber}`;
  }

  function releaseNumberKey(value) {
    const normalized = normalizeText(value);
    return normalized.match(/^\d+$/)?.[0] || releaseNumberFromName(normalized);
  }

  function isNoQa(value) {
    return normalizedHeader(value) === 'без qa';
  }

  function isWeekendDate(date) {
    const day = date.getUTCDay();
    return day === 0 || day === 6;
  }

  function isWorkingCalendarDay(parts, workingDayMap = null, holidayFallbackMap = null) {
    const officialOverride = officialWorkingDayOverride(parts);
    if (officialOverride !== null) {
      return officialOverride;
    }

    const isoDate = formatIsoDate(parts);
    const holidayDates = holidayFallbackMap?.get(parts.year);

    if (holidayDates instanceof Set && holidayDates.has(isoDate)) {
      return false;
    }

    if (!workingDayMap) {
      return !isWeekendDate(new Date(Date.UTC(parts.year, parts.month, parts.day)));
    }

    const value = workingDayMap.get(isoDate);
    if (typeof value === 'boolean') return value;
    return !isWeekendDate(new Date(Date.UTC(parts.year, parts.month, parts.day)));
  }

  function workdayAgeDays(taskDateParts, releaseDateStart, workingDayMap = null, holidayFallbackMap = null) {
    const releaseDateParts = moscowParts(releaseDateStart);
    if (compareDateParts(taskDateParts, releaseDateParts) >= 0) return 0;

    let cursor = nextDateParts(taskDateParts);
    let workdays = 0;

    while (compareDateParts(cursor, releaseDateParts) <= 0) {
      if (isWorkingCalendarDay(cursor, workingDayMap, holidayFallbackMap)) {
        workdays += 1;
      }
      cursor = nextDateParts(cursor);
    }

    return workdays;
  }

  function taskAgeBucket(taskDateParts, releaseDateStart, workingDayMap = null, holidayFallbackMap = null) {
    const ageDays = workdayAgeDays(taskDateParts, releaseDateStart, workingDayMap, holidayFallbackMap);
    if (ageDays <= 0) return 'lessThanOneDay';
    if (ageDays === 1) return 'oneDay';
    return 'moreThanOneDay';
  }

  function releaseStatsKey(dateStart, releaseNumber) {
    return `${dateStart}:${releaseNumber}`;
  }

  function pushToArrayMap(map, key, value) {
    if (!key) return;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(value);
  }

  function summarizeReleaseRecords(records, releaseStart, workingDayMap = null, holidayFallbackMap = null) {
    const summary = {
      taskCount: records.length,
      lessThanOneDay: 0,
      oneDay: 0,
      moreThanOneDay: 0,
      noQa: 0
    };

    for (const record of records) {
      if (record.taskDateParts) {
        summary[taskAgeBucket(record.taskDateParts, releaseStart, workingDayMap, holidayFallbackMap)] += 1;
      }
      if (record.noQa) summary.noQa += 1;
    }

    return summary;
  }

  function findMatchingThreadRecord(task, lookupByKey, lookupByUrl, usedRecordIds) {
    const candidates = [];

    if (task.prKey && lookupByKey.has(task.prKey)) {
      candidates.push(...lookupByKey.get(task.prKey));
    }
    if (task.prUrl && lookupByUrl.has(task.prUrl)) {
      candidates.push(...lookupByUrl.get(task.prUrl));
    }

    return candidates.find(candidate => !usedRecordIds.has(candidate.id)) || null;
  }

  function appendUnusedRecords(target, records, usedRecordIds) {
    const added = [];

    for (const record of records) {
      if (usedRecordIds.has(record.id)) continue;
      usedRecordIds.add(record.id);
      target.push(record);
      added.push(record);
    }

    return added;
  }

  async function getUserMention(userId) {
    if (!userId) return '';

    try {
      const user = await fetchJson(`/api/v4/users/${userId}`);
      const username = normalizeText(user.username).replace(/^@+/, '').toLowerCase();
      if (RELEASE_RESPONSIBLES_BY_USERNAME[username]) return RELEASE_RESPONSIBLES_BY_USERNAME[username];
      return username ? `@${username}` : '';
    } catch {
      return '';
    }
  }

  async function collectReleaseStartThreads(dateStarts) {
    const seenRootIds = new Set();
    const startPosts = [];
    const targetDateStarts = new Set(dateStarts);
    if (!targetDateStarts.size) return new Map();
    const minDateStart = Math.min(...targetDateStarts);

    for (let page = 0; page < 30; page += 1) {
      const payload = await fetchJson(`/api/v4/channels/${CHANNEL_ID}/posts?page=${page}&per_page=200`);
      const order = payload.order || [];
      const postMap = payload.posts || {};
      if (!order.length) break;
      const oldest = Math.min(...order.map(postId => Number(postMap[postId]?.create_at || Date.now())));

      for (const postId of order) {
        const post = postMap[postId];
        if (!post) continue;

        const rootId = post.root_id || post.id;
        if (seenRootIds.has(rootId)) continue;
        seenRootIds.add(rootId);

        let rootPost = postMap[rootId];
        if (!rootPost || rootPost.root_id) {
          try {
            rootPost = await fetchJson(`/api/v4/posts/${rootId}`);
          } catch {
            continue;
          }
        }

        if (!rootPost || rootPost.root_id || !RELEASE_START_RE.test(rootPost.message || '')) continue;
        const dateStart = moscowDateStartMs(moscowParts(rootPost.create_at));
        if (!targetDateStarts.has(dateStart)) continue;

        startPosts.push({
          postId: rootPost.id,
          createAt: rootPost.create_at,
          dateStart,
          link: `${BASE_URL}/${TEAM_PATH}/pl/${rootPost.id}`,
          startTime: formatTimeFromMs(rootPost.create_at),
          responsible: await getUserMention(rootPost.user_id)
        });
      }

      if (oldest < minDateStart) break;
    }

    const byDate = new Map();
    for (const post of startPosts.sort((a, b) => a.createAt - b.createAt)) {
      if (!byDate.has(post.dateStart)) byDate.set(post.dateStart, []);
      byDate.get(post.dateStart).push(post);
    }

    const map = new Map();
    for (const [dateStart, posts] of byDate.entries()) {
      posts.forEach((post, index) => {
        map.set(releaseStatsKey(dateStart, String(index + 1)), post);
      });
    }

    return map;
  }

  function collectReleaseStatsDateRange(sheetRows, options = {}) {
    const targetRelease = normalizeReleaseName(normalizeText(options.releaseNumber));
    if (!targetRelease) return null;

    const headers = sheetRows[0] || [];
    const taskDateIndex = headerIndex(headers, ['Р”Р°С‚Р°']);
    const releaseDateIndex = headerIndex(headers, ['Р”Р°С‚Р° СЂРµР»РёР·Р°']);
    const releaseIndex = headerIndex(headers, ['Р РµР»РёР·']);
    if (taskDateIndex === -1 || releaseDateIndex === -1 || releaseIndex === -1) return null;

    let minTaskDate = null;
    let maxReleaseDate = null;

    for (const row of sheetRows.slice(1)) {
      const releaseName = normalizeReleaseName(row[releaseIndex]);
      if (releaseName !== targetRelease) continue;

      const releaseDateParts = parseSheetDate(row[releaseDateIndex]);
      if (!releaseDateParts || releaseDateParts.year !== RELEASE_STATS_YEAR) continue;

      const taskDateParts = parseSheetDate(row[taskDateIndex]);
      if (taskDateParts && (!minTaskDate || compareDateParts(taskDateParts, minTaskDate) < 0)) {
        minTaskDate = taskDateParts;
      }
      if (!maxReleaseDate || compareDateParts(releaseDateParts, maxReleaseDate) > 0) {
        maxReleaseDate = releaseDateParts;
      }
    }

    if (!maxReleaseDate) return null;
    return {
      start: minTaskDate || maxReleaseDate,
      end: maxReleaseDate
    };
  }

  function buildReleaseStatsRows(sheetRows, releaseStartThreads, options = {}, workingDayMap = null, holidayFallbackMap = null) {
    const targetReleaseRaw = normalizeText(options.releaseNumber);
    const targetRelease = normalizeReleaseName(targetReleaseRaw);
    if (!targetRelease) {
      throw new Error('Укажи номер релиза в формате 07-05/1.');
    }

    const targetReleaseNumber = releaseNumberFromName(targetRelease);
    if (!targetReleaseNumber) {
      throw new Error('Номер релиза должен быть в формате 07-05/1, 07-05/2 и т.д.');
    }

    const headers = sheetRows[0] || [];
    const taskDateIndex = headerIndex(headers, ['Дата']);
    const releaseDateIndex = headerIndex(headers, ['Дата релиза']);
    const releaseIndex = headerIndex(headers, ['Релиз']);
    const qaIndex = headerIndex(headers, ['QA']);
    const stashIndex = headerIndex(headers, ['Stash']);

    if (taskDateIndex === -1 || releaseDateIndex === -1 || releaseIndex === -1 || qaIndex === -1) {
      throw new Error('Не нашел обязательные колонки в листе "Релизы": "Дата", "Дата релиза", "Релиз", "QA".');
    }

    const groups = new Map();
    const allRecordsByPrKey = new Map();
    const allRecordsByPrUrl = new Map();
    const warnings = [];

    for (const [index, row] of sheetRows.slice(1).entries()) {
      const taskDateParts = parseSheetDate(row[taskDateIndex]);
      const releaseDateText = normalizeText(row[releaseDateIndex]);
      const releaseName = normalizeReleaseName(row[releaseIndex]);
      const releaseDateParts = parseSheetDate(releaseDateText);
      const stashUrl = stashIndex === -1 ? '' : normalizePrUrl(row[stashIndex]);
      const stashKey = pullRequestKey(stashUrl || row[stashIndex]);
      const record = {
        id: index,
        releaseName,
        taskDateParts,
        noQa: isNoQa(row[qaIndex]),
        prUrl: stashUrl,
        prKey: stashKey
      };

      if (taskDateParts?.year === RELEASE_STATS_YEAR || releaseDateParts?.year === RELEASE_STATS_YEAR) {
        pushToArrayMap(allRecordsByPrKey, stashKey, record);
        pushToArrayMap(allRecordsByPrUrl, stashUrl, record);
      }

      if (!releaseDateParts) continue;
      if (releaseDateParts.year !== RELEASE_STATS_YEAR) continue;

      if (!releaseName || releaseName !== targetRelease) continue;

      const releaseStart = moscowDateStartMs(releaseDateParts);
      const groupKey = `${releaseStart}:${releaseName}`;
      if (!groups.has(groupKey)) {
        const releaseNumber = releaseNumberFromName(releaseName);
        if (!releaseNumber) continue;

        groups.set(groupKey, {
          releaseDate: formatInputDate(releaseDateParts),
          releaseName,
          releaseNumber,
          sortDate: releaseStart,
          sortReleaseNumber: Number(releaseNumber) || 0,
          records: [],
          recordsByPrKey: new Map(),
          recordsByPrUrl: new Map()
        });
      }

      const group = groups.get(groupKey);
      group.records.push(record);
      pushToArrayMap(group.recordsByPrKey, stashKey, record);
      pushToArrayMap(group.recordsByPrUrl, stashUrl, record);
    }

    if (!groups.size) {
      throw new Error(`Не нашел задач для релиза ${targetRelease} на листе "Релизы".`);
    }

    return {
      warnings,
      rows: [...groups.values()].map(row => {
        const key = releaseStatsKey(row.sortDate, row.releaseNumber);
        const releaseStartThread = releaseStartThreads.get(key);
        let matchedRecords = row.records;
        let taskCount = row.records.length;

        if (releaseStartThread?.tasks?.length) {
          const usedRecordIds = new Set();
          matchedRecords = [];

          for (const task of releaseStartThread.tasks) {
            let match = findMatchingThreadRecord(task, row.recordsByPrKey, row.recordsByPrUrl, usedRecordIds);
            if (!match) {
              match = findMatchingThreadRecord(task, allRecordsByPrKey, allRecordsByPrUrl, usedRecordIds);
            }
            if (!match) continue;
            usedRecordIds.add(match.id);
            matchedRecords.push(match);
          }

          const sheetOnlyRecords = appendUnusedRecords(matchedRecords, row.records, usedRecordIds);
          taskCount = Math.max(releaseStartThread.taskCount, matchedRecords.length);

          if (sheetOnlyRecords.length) {
            warnings.push(
              `Релиз ${row.releaseName}: дополнительно учтены ${sheetOnlyRecords.length} задач из листа "Релизы", которых нет в релизном треде.`
            );
          }

          if (matchedRecords.length !== releaseStartThread.taskCount) {
            warnings.push(
              `Релиз ${row.releaseName}: в треде ${releaseStartThread.taskCount} задач, после сверки с листом "Релизы" учитывается ${matchedRecords.length}.`
            );
          }
        }

        const summary = summarizeReleaseRecords(matchedRecords, row.sortDate, workingDayMap, holidayFallbackMap);

        return {
          releaseDate: row.releaseDate,
          releaseName: row.releaseName,
          releaseNumber: row.releaseNumber,
          sortDate: row.sortDate,
          sortReleaseNumber: row.sortReleaseNumber,
          taskCount,
          lessThanOneDay: summary.lessThanOneDay,
          oneDay: summary.oneDay,
          moreThanOneDay: summary.moreThanOneDay,
          noQa: summary.noQa,
          link: releaseStartThread?.link || '',
          startTime: releaseStartThread?.startTime || '',
          responsible: releaseStartThread?.responsible || ''
        };
      }).sort((a, b) =>
        a.sortDate - b.sortDate ||
        a.sortReleaseNumber - b.sortReleaseNumber ||
        a.releaseName.localeCompare(b.releaseName)
      )
    };
  }

  function releaseStatsRowsToTsv(rows) {
    return rows.map(row => {
      const values = new Array(RELEASE_STATS_TSV_COLUMN_COUNT).fill('');

      values[0] = row.releaseDate;
      values[1] = row.releaseNumber;
      values[2] = row.link || '';
      values[3] = row.startTime || '';
      values[4] = '';
      values[5] = String(row.taskCount);
      values[6] = String(row.lessThanOneDay);
      values[7] = String(row.oneDay);
      values[8] = String(row.moreThanOneDay);
      values[9] = String(row.noQa);
      values[10] = '';
      values[11] = row.responsible || '';
      return values.join('\t');
    }).join('\n');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function releaseStatsRowsToHtml(rows) {
    const baseStyle = 'font-family:&quot;Roboto Mono&quot;,monospace;font-size:10pt;font-weight:400;font-style:normal;text-decoration:none;vertical-align:bottom;';
    const rightStyle = `${baseStyle}text-align:right;`;
    const leftStyle = `${baseStyle}text-align:left;`;
    const centerStyle = `${baseStyle}text-align:center;`;
    const linkStyle = `${leftStyle}color:#1155cc;text-decoration:underline;`;

    const body = rows.map(row => {
      const values = [
        { text: row.releaseDate, style: rightStyle },
        { text: row.releaseNumber, style: rightStyle },
        { text: row.link || '', style: linkStyle },
        { text: row.startTime || '', style: centerStyle },
        { text: '', style: centerStyle },
        { text: String(row.taskCount), style: rightStyle },
        { text: String(row.lessThanOneDay), style: rightStyle },
        { text: String(row.oneDay), style: rightStyle },
        { text: String(row.moreThanOneDay), style: rightStyle },
        { text: String(row.noQa), style: rightStyle },
        { text: '', style: baseStyle },
        { text: row.responsible || '', style: leftStyle }
      ];

      return `<tr>${values.map(cell => `<td style="${cell.style}">${escapeHtml(cell.text)}</td>`).join('')}</tr>`;
    }).join('');

    return `<!doctype html><html><head><meta charset="utf-8"></head><body><table>${body}</table></body></html>`;
  }

  async function collectReleaseStats(options = {}) {
    const releaseUrl = `https://docs.google.com/spreadsheets/d/${RELEASE_SHEET_ID}/export?format=csv&gid=${RELEASE_SHEET_GID}`;
    const releaseCsv = await fetchText(releaseUrl);
    const rows = parseCsv(releaseCsv);
    const dateRange = collectReleaseStatsDateRange(rows, options);
    const holidayFallbackMap = dateRange
      ? await buildHolidayFallbackMap(dateRange.start, dateRange.end)
      : null;
    const workingDayMap = dateRange
      ? await buildWorkingDayMap(dateRange.start, dateRange.end)
      : null;
    const preliminary = buildReleaseStatsRows(rows, new Map(), options, workingDayMap, holidayFallbackMap);
    const releaseStartThreads = await collectReleaseStartThreads(preliminary.rows.map(row => row.sortDate));
    const releaseThreadsWithTasks = await collectReleaseThreadTasks(releaseStartThreads);
    const statsResult = buildReleaseStatsRows(rows, releaseThreadsWithTasks, options, workingDayMap, holidayFallbackMap);

    return {
      rows: statsResult.rows,
      warnings: statsResult.warnings,
      html: releaseStatsRowsToHtml(statsResult.rows),
      tsv: releaseStatsRowsToTsv(statsResult.rows)
    };
  }

  async function readThread(postId) {
    const payload = await fetchJson(`/api/v4/posts/${postId}/thread?collapsed=false&collapsed_threads=false&perPage=200`);
    const posts = (payload.order || []).map(itemId => payload.posts[itemId]).filter(Boolean);
    return {
      posts,
      rootPost: posts.find(post => post.id === postId) || posts[0] || null
    };
  }

  function splitMarkdownRow(line) {
    return String(line || '')
      .trim()
      .replace(/^\|/, '')
      .replace(/\|$/, '')
      .split('|')
      .map(cell => normalizeText(cell));
  }

  function isMarkdownSeparatorRow(cells) {
    return cells.length > 1 && cells.every(cell => /^:?-{3,}:?$/.test(cell.replace(/\s+/g, '')));
  }

  function cleanTableCell(value) {
    return stripMarkup(
      String(value || '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/<[^>]+>/g, '')
        .replace(/\*\*/g, '')
    ).replace(/^@+/, '');
  }

  function columnIndex(headers, names) {
    return headers.findIndex(header => names.some(name => header.includes(name)));
  }

  function parseReleaseRowsFromTableBlock(lines) {
    if (lines.length < 3) return [];

    const headers = splitMarkdownRow(lines[0]).map(header => cleanTableCell(header).toLowerCase());
    const separator = splitMarkdownRow(lines[1]);
    if (!isMarkdownSeparatorRow(separator)) return [];

    const linkIndex = columnIndex(headers, ['ссылка', 'pull request', 'pr', 'stash']);
    const developerIndex = columnIndex(headers, ['разработчик', 'developer']);
    const responsibleIndex = columnIndex(headers, ['ответственный', 'qa']);
    if (linkIndex === -1 || developerIndex === -1) return [];

    const rows = [];
    for (const line of lines.slice(2)) {
      const cells = splitMarkdownRow(line);
      const url = normalizePrUrl(cells[linkIndex]);
      const developer = cleanTableCell(cells[developerIndex]);
      const responsible = responsibleIndex >= 0 ? cleanTableCell(cells[responsibleIndex]) : 'Не указан';
      if (!url || !developer) continue;
      rows.push({ url, developer, responsible: responsible || 'Не указан' });
    }

    return rows;
  }

  function parseReleaseRowsFromMessage(message) {
    const rows = [];
    const tableLines = [];

    function flushTable() {
      rows.push(...parseReleaseRowsFromTableBlock(tableLines));
      tableLines.length = 0;
    }

    for (const rawLine of String(message || '').split(/\r?\n/)) {
      const line = rawLine.trim();
      if (line.startsWith('|') && line.includes('|')) {
        tableLines.push(line);
      } else if (tableLines.length) {
        flushTable();
      }
    }

    if (tableLines.length) flushTable();
    return rows;
  }

  function uniqueRowsByUrl(rows) {
    return [...new Map(rows.map(row => [row.url, row])).values()];
  }

  async function collectReleaseThreadTasks(releaseStartThreads) {
    const result = new Map();

    for (const [key, releaseStartThread] of releaseStartThreads.entries()) {
      if (!releaseStartThread?.postId) {
        result.set(key, releaseStartThread);
        continue;
      }

      try {
        const thread = await readThread(releaseStartThread.postId);
        const tasks = uniqueRowsByUrl(
          thread.posts.flatMap(post => parseReleaseRowsFromMessage(post.message || ''))
        ).map(task => ({
          ...task,
          prUrl: normalizePrUrl(task.url),
          prKey: pullRequestKey(task.url)
        }));

        result.set(key, {
          ...releaseStartThread,
          taskCount: tasks.length,
          tasks
        });
      } catch {
        result.set(key, releaseStartThread);
      }
    }

    return result;
  }

  async function findLatestReleaseStartPost() {
    for (let page = 0; page < 20; page += 1) {
      const payload = await fetchJson(`/api/v4/channels/${CHANNEL_ID}/posts?page=${page}&per_page=200`);
      const order = payload.order || [];
      const postMap = payload.posts || {};

      for (const postId of order) {
        const post = postMap[postId];
        if (!post || post.root_id) continue;
        if (RELEASE_START_RE.test(post.message || '')) return post;
      }

      if (!payload.has_next) break;
    }

    return null;
  }

  async function getLatestReleaseThreadRows() {
    const releasePost = await findLatestReleaseStartPost();
    if (!releasePost) {
      throw new Error('Не нашел последний тред с фразой "Начинаем релиз" в dev-merge-to-master.');
    }

    const thread = await readThread(releasePost.id);
    const rows = uniqueRowsByUrl(
      thread.posts.flatMap(post => parseReleaseRowsFromMessage(post.message || ''))
    );

    if (!rows.length) {
      throw new Error(`Нашел тред релиза, но не нашел в нем таблицу PR: ${BASE_URL}/${TEAM_PATH}/pl/${releasePost.id}`);
    }

    return {
      threadUrl: `${BASE_URL}/${TEAM_PATH}/pl/${releasePost.id}`,
      expected: rows
    };
  }

  async function compareLatestReleaseThreadWithMerged(mergedPrs) {
    const releaseThread = await getLatestReleaseThreadRows();
    const mergedPrKeys = new Set(
      (mergedPrs || [])
        .map(pr => pullRequestKey(pr.url))
        .filter(Boolean)
    );
    const expectedPrKeys = new Set(
      releaseThread.expected
        .map(row => pullRequestKey(row.url))
        .filter(Boolean)
    );
    const missing = releaseThread.expected.filter(row => !mergedPrKeys.has(pullRequestKey(row.url)));
    const extra = (mergedPrs || []).filter(pr => !expectedPrKeys.has(pullRequestKey(pr.url)));

    return {
      ...releaseThread,
      merged: mergedPrs || [],
      missing,
      extra
    };
  }

  function releaseThreadMessage(releaseNumber) {
    return `${RELEASE_THREAD_MESSAGE} ${normalizeText(releaseNumber)}`;
  }

  function hasReleaseMarker(posts, releaseNumber) {
    const marker = releaseThreadMessage(releaseNumber).toLowerCase();
    return posts.some(post => normalizeText(post.message).toLowerCase().includes(marker));
  }

  function releaseReactionEmoji(releaseNumber) {
    const normalized = normalizeText(releaseNumber);
    if (normalized.endsWith('/1')) return 'one';
    if (normalized.endsWith('/2')) return 'two';
    return null;
  }

  async function addReaction(postId, emojiName) {
    const userId = await getCookie('MMUSERID');
    if (!userId) {
      throw new Error('Не удалось прочитать MMUSERID для реакции.');
    }

    return postJson('/api/v4/reactions', {
      user_id: userId,
      post_id: postId,
      emoji_name: emojiName
    });
  }

  async function removeReaction(postId, emojiName) {
    const userId = await getCookie('MMUSERID');
    if (!userId) {
      throw new Error('Не удалось прочитать MMUSERID для снятия реакции.');
    }

    return deleteJson(`/api/v4/users/${userId}/posts/${postId}/reactions/${emojiName}`);
  }

  async function mapWithConcurrency(items, limit, mapper) {
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        const currentIndex = nextIndex;
        nextIndex += 1;
        results[currentIndex] = await mapper(items[currentIndex], currentIndex);
      }
    }

    await Promise.all(
      Array.from({ length: Math.min(limit, items.length) }, () => worker())
    );
    return results;
  }

  async function markOneReleaseThread(row, releaseNumber, emojiName) {
    const postId = extractPostId(row.threadUrl);
    if (!postId) {
      return { type: 'failed', row: { ...row, error: 'Не удалось извлечь id треда из ссылки.' } };
    }

    try {
      const thread = await readThread(postId);
      if (!thread.rootPost?.channel_id) {
        return { type: 'failed', row: { ...row, error: 'Не удалось определить канал треда.' } };
      }

      if (hasReleaseMarker(thread.posts, releaseNumber)) {
        return { type: 'alreadyMarked', row };
      }

      await postJson('/api/v4/posts', {
        channel_id: thread.rootPost.channel_id,
        root_id: postId,
        message: releaseThreadMessage(releaseNumber)
      });

      const result = { type: 'added', row };
      if (!emojiName) return result;

      try {
        await addReaction(postId, emojiName);
        result.reacted = row;
        try {
          await removeReaction(postId, 'hourglass_flowing_sand');
          result.hourglassRemoved = row;
        } catch (error) {
          result.hourglassRemoveFailed = { ...row, error: error.message };
        }
      } catch (error) {
        result.reactionFailed = { ...row, error: error.message };
      }

      return result;
    } catch (error) {
      return { type: 'failed', row: { ...row, error: error.message } };
    }
  }

  async function markReleaseThreads(releaseNumber) {
    const rows = await readReleaseThreadRows(releaseNumber);
    const emojiName = releaseReactionEmoji(releaseNumber);
    const result = {
      releaseNumber: normalizeText(releaseNumber),
      reaction: emojiName,
      matchedRows: rows.length,
      added: [],
      reacted: [],
      reactionFailed: [],
      hourglassRemoved: [],
      hourglassRemoveFailed: [],
      alreadyMarked: [],
      failed: []
    };

    const threadResults = await mapWithConcurrency(
      rows,
      5,
      row => markOneReleaseThread(row, releaseNumber, emojiName)
    );

    for (const threadResult of threadResults) {
      if (threadResult.type === 'added') {
        result.added.push(threadResult.row);
        if (threadResult.reacted) result.reacted.push(threadResult.reacted);
        if (threadResult.reactionFailed) result.reactionFailed.push(threadResult.reactionFailed);
        if (threadResult.hourglassRemoved) result.hourglassRemoved.push(threadResult.hourglassRemoved);
        if (threadResult.hourglassRemoveFailed) result.hourglassRemoveFailed.push(threadResult.hourglassRemoveFailed);
      } else if (threadResult.type === 'alreadyMarked') {
        result.alreadyMarked.push(threadResult.row);
      } else if (threadResult.type === 'failed') {
        result.failed.push(threadResult.row);
      }
    }

    return result;
  }

  class MattermostClient {
    constructor() {
      this.pagePosts = new Map();
      this.pageRepliesByRoot = new Map();
      this.usernames = new Map();
      this.threadPosts = new Map();
      this.reactions = new Map();
      this.warnings = [];
    }

    ingestChannelPayload(payload) {
      for (const [postId, post] of Object.entries(payload.posts || {})) {
        const existing = this.pagePosts.get(postId);
        if (existing && Number(existing.update_at || 0) >= Number(post.update_at || 0)) continue;
        this.pagePosts.set(postId, post);

        if (!post.root_id) continue;
        if (!this.pageRepliesByRoot.has(post.root_id)) this.pageRepliesByRoot.set(post.root_id, new Map());
        this.pageRepliesByRoot.get(post.root_id).set(postId, post);
      }
    }

    async getChannelPage(page, perPage = 200) {
      const payload = await fetchJson(`/api/v4/channels/${CHANNEL_ID}/posts?page=${page}&per_page=${perPage}`);
      this.ingestChannelPayload(payload);
      return payload;
    }

    reactionNamesFromPost(post) {
      if (!post) return null;
      const reactions = post.metadata?.reactions;
      if (reactions) {
        return [...new Set(reactions.map(item => item.emoji_name).filter(Boolean))].sort();
      }
      return post.has_reactions === false ? [] : null;
    }

    async getReactions(postId) {
      const fromPage = this.reactionNamesFromPost(this.pagePosts.get(postId));
      if (fromPage !== null) return fromPage;
      if (this.reactions.has(postId)) return this.reactions.get(postId);

      try {
        const data = await fetchJson(`/api/v4/posts/${postId}/reactions`);
        const names = [...new Set((data || []).map(item => item.emoji_name).filter(Boolean))].sort();
        this.reactions.set(postId, names);
        return names;
      } catch (error) {
        this.warnings.push(`Не удалось прочитать реакции ${postId}: ${error.message}`);
        return [];
      }
    }

    async getUsername(userId) {
      if (this.usernames.has(userId)) return this.usernames.get(userId);
      const data = await fetchJson(`/api/v4/users/${userId}`);
      const username = `@${data.username}`;
      this.usernames.set(userId, username);
      return username;
    }

    async getThreadPosts(postId) {
      if (this.threadPosts.has(postId)) return this.threadPosts.get(postId);

      const rootPost = this.pagePosts.get(postId);
      const localReplies = [...(this.pageRepliesByRoot.get(postId) || new Map()).values()];
      if (rootPost && localReplies.length >= Number(rootPost.reply_count || 0)) {
        const posts = [rootPost, ...localReplies.sort((a, b) => a.create_at - b.create_at)];
        this.threadPosts.set(postId, posts);
        return posts;
      }

      try {
        const payload = await fetchJson(`/api/v4/posts/${postId}/thread?collapsed=false&collapsed_threads=false&perPage=200`);
        const posts = (payload.order || []).map(itemId => payload.posts[itemId]).filter(Boolean);
        this.threadPosts.set(postId, posts);
        return posts;
      } catch (error) {
        this.warnings.push(`Не удалось прочитать тред ${postId}: ${error.message}`);
        return [];
      }
    }

    async parseThread(post) {
      const parsedFields = parseDevMergeFields(post.message || '');
      const stashUrls = extractStashUrls(post.message || '');

      const needsReplies = !parsedFields.feature ||
        !parsedFields.priority ||
        !hasMeaningfulFg(parsedFields.fg);

      if (needsReplies) {
        const threadPosts = await this.getThreadPosts(post.id);
        for (const reply of threadPosts.slice(1)) {
          const replyFields = parseDevMergeFields(reply.message || '');
          if (replyFields.priority && !parsedFields.priority) parsedFields.priority = replyFields.priority;
          if (replyFields.feature && !parsedFields.feature) parsedFields.feature = replyFields.feature;
          if (replyFields.developer && !parsedFields.developer) parsedFields.developer = replyFields.developer;
          if (replyFields.fg && !hasMeaningfulFg(parsedFields.fg)) parsedFields.fg = replyFields.fg;

          if (!stashUrls.length) {
            for (const url of extractStashUrls(reply.message || '')) {
              if (!stashUrls.includes(url)) stashUrls.push(url);
            }
          }
        }
      }

      return {
        priority: normalizePriority(parsedFields.priority),
        feature: stripMarkup(parsedFields.feature),
        developerField: stripMarkup(parsedFields.developer),
        hasFg: hasMeaningfulFg(parsedFields.fg),
        stashUrls
      };
    }
  }

  async function collectRootPosts(client, range) {
    const posts = [];
    const seenIds = new Set();

    for (let page = 0; page < 20; page += 1) {
      let payload;
      try {
        payload = await client.getChannelPage(page, 200);
      } catch (error) {
        client.warnings.push(`Не удалось прочитать страницу ${page}: ${error.message}`);
        break;
      }

      const order = payload.order || [];
      const postMap = payload.posts || {};
      if (!order.length) break;

      const oldest = Math.min(...order.map(postId => Number(postMap[postId]?.create_at || Date.now())));

      for (const postId of [...order].reverse()) {
        const post = postMap[postId];
        if (!post || seenIds.has(postId)) continue;
        seenIds.add(postId);
        if (post.root_id) continue;
        if (post.create_at < range.start || post.create_at > range.end) continue;
        posts.push(post);
      }

      if (oldest < range.start || !payload.has_next) break;
    }

    return posts.sort((a, b) => a.create_at - b.create_at);
  }

  async function buildRows(client, rootPosts) {
    const rows = [];

    for (const post of rootPosts) {
      if (isServicePost(post.message || '')) continue;

      const parsed = await client.parseThread(post);
      if (!parsed.stashUrls.length) continue;

      const reactionNames = new Set(await client.getReactions(post.id));
      if ([...reactionNames].some(name => PROCESSED_REACTIONS.has(name))) continue;

      const priority = normalizePriority(parsed.priority, reactionNames.has('b'));
      const developer = parsed.developerField || await client.getUsername(post.user_id);
      const slackUrl = `${BASE_URL}/${TEAM_PATH}/pl/${post.id}`;
      const dateValue = effectiveDate(post.create_at);

      for (const stashUrl of parsed.stashUrls) {
        rows.push({
          sortTs: post.create_at,
          date: dateValue,
          priority,
          slack: slackUrl,
          stash: stashUrl,
          feature: parsed.feature,
          developer,
          fgTrue: parsed.hasFg
        });
      }
    }

    return rows;
  }

  function rowsToTsv(rows) {
    return rows.map(row => [
      row.date,
      '',
      row.priority,
      row.slack,
      row.stash,
      '',
      row.feature,
      row.developer,
      '',
      row.fgTrue ? 'true' : 'false'
    ].join('\t')).join('\n');
  }

  async function collect(options = {}) {
    const client = new MattermostClient();
    const range = dateRangeForDates(options.startDate, options.endDate);
    const rootPosts = await collectRootPosts(client, range);
    const rows = await buildRows(client, rootPosts);

    return {
      rows,
      tsv: rowsToTsv(rows),
      rootPostCount: rootPosts.length,
      warnings: client.warnings
    };
  }

  globalThis.DevMergeQueue = {
    collect,
    collectReleaseStats,
    compareLatestReleaseThreadWithMerged,
    markReleaseThreads,
    releaseStatsRowsToHtml,
    releaseStatsRowsToTsv,
    rowsToTsv
  };
})();
