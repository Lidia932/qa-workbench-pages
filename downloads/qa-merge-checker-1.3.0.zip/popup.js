const storageKeys = {
  buildId: 'qaMergeChecker.buildId',
  mergedPrs: 'qaMergeChecker.mergedPrs',
  capturedAt: 'qaMergeChecker.capturedAt',
  lastReport: 'qaMergeChecker.lastReport',
  devMergeRows: 'qaMergeChecker.devMergeRows',
  devMergeTsv: 'qaMergeChecker.devMergeTsv',
  devMergeStartDate: 'qaMergeChecker.devMergeStartDate',
  devMergeEndDate: 'qaMergeChecker.devMergeEndDate',
  releaseStatsRows: 'qaMergeChecker.releaseStatsRows',
  releaseStatsTsv: 'qaMergeChecker.releaseStatsTsv',
  releaseStatsHtml: 'qaMergeChecker.releaseStatsHtml',
  releaseStatsWarnings: 'qaMergeChecker.releaseStatsWarnings',
  releaseStatsReleaseNumber: 'qaMergeChecker.releaseStatsReleaseNumber',
  releaseNumber: 'qaMergeChecker.releaseNumber',
  lastView: 'qaMergeChecker.lastView'
};

const statusEl = document.querySelector('#status');
const outputEl = document.querySelector('#output');
const windowMinutesEl = document.querySelector('#windowMinutes');
const devMergeStartDateEl = document.querySelector('#devMergeStartDate');
const devMergeEndDateEl = document.querySelector('#devMergeEndDate');
const releaseStatsReleaseNumberEl = document.querySelector('#releaseStatsReleaseNumber');
const releaseNumberEl = document.querySelector('#releaseNumber');
const checkDeployButton = document.querySelector('#checkDeploy');
const fetchDevMergeQueueButton = document.querySelector('#fetchDevMergeQueue');
const copyDevMergeTsvButton = document.querySelector('#copyDevMergeTsv');
const fetchReleaseStatsButton = document.querySelector('#fetchReleaseStats');
const copyReleaseStatsTsvButton = document.querySelector('#copyReleaseStatsTsv');
const markReleaseThreadsButton = document.querySelector('#markReleaseThreads');
const clearDataButton = document.querySelector('#clearData');
const busyOverlayEl = document.querySelector('#busyOverlay');
const busyTextEl = document.querySelector('#busyText');

function setBusy(isBusy, message = 'Подождите, скрипт выполняется...') {
  checkDeployButton.disabled = isBusy;
  fetchDevMergeQueueButton.disabled = isBusy;
  copyDevMergeTsvButton.disabled = isBusy;
  fetchReleaseStatsButton.disabled = isBusy;
  copyReleaseStatsTsvButton.disabled = isBusy;
  markReleaseThreadsButton.disabled = isBusy;
  clearDataButton.disabled = isBusy;
  busyTextEl.textContent = message;
  busyOverlayEl.hidden = !isBusy;
}

function setStatus(message) {
  statusEl.textContent = message;
}

function setOutput(value) {
  outputEl.textContent = value || '';
}

function formatDateInput(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function defaultDateRange() {
  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - 1);

  return {
    startDate: formatDateInput(start),
    endDate: formatDateInput(end)
  };
}

function selectedDevMergeRange() {
  return {
    startDate: devMergeStartDateEl.value,
    endDate: devMergeEndDateEl.value
  };
}

function selectedReleaseStatsRelease() {
  return {
    releaseNumber: releaseStatsReleaseNumberEl.value.trim()
  };
}

async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    if (!/Receiving end does not exist|Could not establish connection/i.test(error.message)) {
      throw error;
    }

    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });

    return chrome.tabs.sendMessage(tabId, message);
  }
}

async function currentWindowTabs() {
  return chrome.tabs.query({ currentWindow: true });
}

function canInspectTab(tab) {
  return Boolean(tab?.id) && /^https?:\/\//i.test(tab.url || '');
}

function isDeployTab(tab) {
  return /^https:\/\/cloud\.roistat\.com\/admin\/deploy(?:[/?#]|$)/i.test(tab.url || '');
}

function formatMerged(prs) {
  if (!prs.length) return 'Не нашел смерженных PR на странице деплойницы.';

  return prs
    .map(pr => `${pr.url} — ${pr.developer}`)
    .join('\n');
}

function formatMissing(missing, windowMinutes) {
  if (!missing.length) {
    return `Все ок: все PR из треда найдены в смерженных за последние ${windowMinutes} минут.`;
  }

  const lines = [
    `Не нашел в смерженных за последние ${windowMinutes} минут:`,
    '',
    ...missing.map((row, index) => `${index + 1}. ${row.developer} — ${row.url} — QA: ${row.responsible}`)
  ];

  return lines.join('\n');
}

function formatExtra(extra) {
  if (!extra.length) {
    return 'Лишних PR в деплойнице нет: все смерженные PR есть в релизном треде.';
  }

  const lines = [
    'Лишние PR в деплойнице, которых нет в релизном треде:',
    '',
    ...extra.map((pr, index) => `${index + 1}. ${pr.developer} — ${pr.url}`)
  ].join('\n');
}

function formatDevMergeRows(rows, warnings = []) {
  const lines = [];

  if (!rows.length) {
    lines.push('Не нашёл необработанных тредов для занесения в таблицу.');
  } else {
    lines.push('Готовые строки TSV:');
    lines.push('');
    lines.push(DevMergeQueue.rowsToTsv(rows));
  }

  if (warnings.length) {
    lines.push('');
    lines.push('Предупреждения:');
    lines.push(...warnings.map(warning => `- ${warning}`));
  }

  return lines.join('\n');
}

function formatReleaseStatsRows(rows, warnings = []) {
  if (!rows.length) {
    return 'Не нашел релизы в выбранном диапазоне дат.';
  }

  const lines = [
    'Готовая статистика TSV:',
    '',
    DevMergeQueue.releaseStatsRowsToTsv(rows)
  ];

  if (warnings.length) {
    lines.push('');
    lines.push('РџСЂРµРґСѓРїСЂРµР¶РґРµРЅРёСЏ:');
    lines.push(...warnings.map(warning => `- ${warning}`));
  }

  return lines.join('\n');
}

function formatReleaseStatsRows(rows, warnings = []) {
  if (!rows.length) {
    return 'Не нашел релизы в выбранном диапазоне дат.';
  }

  const lines = [
    'Готовая статистика TSV:',
    '',
    DevMergeQueue.releaseStatsRowsToTsv(rows)
  ];

  if (warnings.length) {
    lines.push('');
    lines.push('Предупреждения:');
    lines.push(...warnings.map(warning => `- ${warning}`));
  }

  return lines.join('\n');
}

function formatReleaseResult(result) {
  const lines = [
    `Релиз: ${result.releaseNumber}`,
    `Реакция: ${result.reaction ? `:${result.reaction}:` : 'не выбрана'}`,
    `Строк в таблице: ${result.matchedRows}`,
    `Сообщение добавлено: ${result.added.length}`,
    `Реакция поставлена: ${result.reacted.length}`,
    `Hourglass снят: ${result.hourglassRemoved.length}`,
    `Уже было в треде: ${result.alreadyMarked.length}`,
    `Ошибки сообщений: ${result.failed.length}`,
    `Ошибки реакций: ${result.reactionFailed.length}`,
    `Ошибки снятия hourglass: ${result.hourglassRemoveFailed.length}`
  ];

  if (result.added.length) {
    lines.push('');
    lines.push('Добавлено:');
    lines.push(...result.added.map(row => `- строка ${row.sheetRowNumber}: ${row.threadUrl}`));
  }

  if (result.alreadyMarked.length) {
    lines.push('');
    lines.push('Уже было:');
    lines.push(...result.alreadyMarked.map(row => `- строка ${row.sheetRowNumber}: ${row.threadUrl}`));
  }

  if (result.failed.length) {
    lines.push('');
    lines.push('Не удалось обработать:');
    lines.push(...result.failed.map(row => `- строка ${row.sheetRowNumber}: ${row.threadUrl} — ${row.error}`));
  }

  if (result.reactionFailed.length) {
    lines.push('');
    lines.push('Не удалось поставить реакцию:');
    lines.push(...result.reactionFailed.map(row => `- строка ${row.sheetRowNumber}: ${row.threadUrl} — ${row.error}`));
  }

  if (result.hourglassRemoveFailed.length) {
    lines.push('');
    lines.push('Не удалось снять hourglass:');
    lines.push(...result.hourglassRemoveFailed.map(row => `- строка ${row.sheetRowNumber}: ${row.threadUrl} — ${row.error}`));
  }

  return lines.join('\n');
}

async function findDeployData(tabs, windowMinutes) {
  const candidates = [];
  const emptyCandidates = [];
  const deployTabs = tabs.filter(tab => canInspectTab(tab) && isDeployTab(tab));

  for (const tab of deployTabs) {
    try {
      const response = await sendToTab(tab.id, { type: 'PARSE_DEPLOY', windowMinutes });
      if (response?.ok && response.prs?.length) {
        candidates.push({ tab, prs: response.prs, stats: response.stats });
      } else if (response?.ok) {
        emptyCandidates.push({ tab, prs: [], stats: response.stats });
      }
    } catch {
      // Some pages disallow script injection; they are irrelevant for this check.
    }
  }

  return candidates.sort((a, b) => b.prs.length - a.prs.length)[0] ||
    emptyCandidates.sort((a, b) => (b.stats?.mergeMentions || 0) - (a.stats?.mergeMentions || 0))[0] ||
    (deployTabs[0] ? { tab: deployTabs[0], prs: [], stats: {} } : null);
}

async function checkDeploy() {
  setBusy(true, 'Проверяю деплойницу...');

  try {
    const windowMinutes = Number(windowMinutesEl.value || 30);
    const tabs = await currentWindowTabs();
    const deployData = await findDeployData(tabs, windowMinutes);

    if (!deployData) {
      throw new Error('Не нашел открытую вкладку деплойницы: https://cloud.roistat.com/admin/deploy');
    }

    const comparison = await DevMergeQueue.compareLatestReleaseThreadWithMerged(deployData.prs);
    const report = [
      `Тред релиза: ${comparison.threadUrl}`,
      '',
      formatMissing(comparison.missing, windowMinutes),
      '',
      formatExtra(comparison.extra)
    ].join('\n');

    await chrome.storage.local.set({
      [storageKeys.mergedPrs]: deployData.prs,
      [storageKeys.capturedAt]: Date.now(),
      [storageKeys.lastReport]: report,
      [storageKeys.lastView]: 'deployReport'
    });
    setStatus(`В последнем релизном треде PR: ${comparison.expected.length}. В деплойнице: ${deployData.prs.length}. Не найдены: ${comparison.missing.length}. Лишние: ${comparison.extra.length}.`);
    setOutput(report);
  } catch (error) {
    setStatus('Ошибка при проверке PR.');
    setOutput(error.message);
  } finally {
    setBusy(false);
  }
}

async function fetchDevMergeQueue() {
  setBusy(true, 'Собираю строки...');

  try {
    const range = selectedDevMergeRange();
    const result = await DevMergeQueue.collect(range);

    await chrome.storage.local.set({
      [storageKeys.devMergeRows]: result.rows,
      [storageKeys.devMergeTsv]: result.tsv,
      [storageKeys.devMergeStartDate]: range.startDate,
      [storageKeys.devMergeEndDate]: range.endDate,
      [storageKeys.lastView]: 'devMergeRows'
    });

    setStatus(`Период ${range.startDate} - ${range.endDate}. Проверено тредов: ${result.rootPostCount}. Готовых строк: ${result.rows.length}.`);
    setOutput(formatDevMergeRows(result.rows, result.warnings));
  } catch (error) {
    setStatus('Ошибка при сборе тредов dev-merge.');
    setOutput([
      error.message,
      '',
      'Проверь, что Platrum Chat открыт в этом же Chrome-профиле и ты залогинена.'
    ].join('\n'));
  } finally {
    setBusy(false);
  }
}

async function copyDevMergeTsv() {
  const stored = await chrome.storage.local.get([storageKeys.devMergeTsv]);
  const tsv = stored[storageKeys.devMergeTsv] || '';

  if (!tsv) {
    setStatus('Сначала собери треды dev-merge.');
    return;
  }

  await navigator.clipboard.writeText(tsv);
  setStatus('TSV скопирован в буфер обмена.');
}

async function writeClipboard(text) {
  await navigator.clipboard.writeText(text);
  return 'text';
}

async function fetchReleaseStats() {
  setBusy(true, 'Собираю статистику по релизам...');

  try {
    const release = selectedReleaseStatsRelease();
    await chrome.storage.local.remove([
      storageKeys.releaseStatsRows,
      storageKeys.releaseStatsTsv,
      storageKeys.releaseStatsHtml,
      storageKeys.releaseStatsWarnings
    ]);
    const result = await DevMergeQueue.collectReleaseStats(release);

    await chrome.storage.local.set({
      [storageKeys.releaseStatsRows]: result.rows,
      [storageKeys.releaseStatsTsv]: result.tsv,
      [storageKeys.releaseStatsHtml]: result.html,
      [storageKeys.releaseStatsWarnings]: result.warnings || [],
      [storageKeys.releaseStatsReleaseNumber]: release.releaseNumber,
      [storageKeys.lastView]: 'releaseStats'
    });

    setStatus(`Релиз ${release.releaseNumber}. Готовых строк статистики: ${result.rows.length}.`);
    setOutput(formatReleaseStatsRows(result.rows, result.warnings));
  } catch (error) {
    setStatus('Ошибка при сборе статистики по релизам.');
    setOutput([
      error.message,
      '',
      'Проверь, что Google Sheets открыт и доступен в этом Chrome-профиле.'
    ].join('\n'));
  } finally {
    setBusy(false);
  }
}

async function copyReleaseStatsTsv() {
  const stored = await chrome.storage.local.get([storageKeys.releaseStatsTsv]);
  const tsv = stored[storageKeys.releaseStatsTsv] || '';

  if (!tsv) {
    setStatus('Сначала собери статистику по релизам.');
    return;
  }

  await writeClipboard(tsv);
  setStatus('TSV статистики скопирован без форматирования.');
}

async function markReleaseThreads() {
  setBusy(true, 'Пишу в треды...');

  try {
    const releaseNumber = releaseNumberEl.value.trim();
    const result = await DevMergeQueue.markReleaseThreads(releaseNumber);

    await chrome.storage.local.set({
      [storageKeys.releaseNumber]: releaseNumber,
      [storageKeys.lastView]: 'releaseResult'
    });

    setStatus(`Релиз ${result.releaseNumber}: добавлено ${result.added.length}, реакций ${result.reacted.length}, hourglass снят ${result.hourglassRemoved.length}, уже было ${result.alreadyMarked.length}, ошибок ${result.failed.length + result.reactionFailed.length + result.hourglassRemoveFailed.length}.`);
    setOutput(formatReleaseResult(result));
  } catch (error) {
    setStatus('Ошибка при сборке релиза.');
    setOutput([
      error.message,
      '',
      'Проверь, что ты залогинена в Google Sheets и Platrum Chat в этом же Chrome-профиле.'
    ].join('\n'));
  } finally {
    setBusy(false);
  }
}

async function clearData() {
  await chrome.storage.local.remove(Object.values(storageKeys));
  setStatus('Данные очищены.');
  setOutput('');
}

async function clearReleaseStatsCache() {
  const stored = await chrome.storage.local.get([storageKeys.lastView]);
  await chrome.storage.local.remove([
    storageKeys.releaseStatsRows,
    storageKeys.releaseStatsTsv,
    storageKeys.releaseStatsHtml,
    storageKeys.releaseStatsWarnings
  ]);

  if (stored[storageKeys.lastView] === 'releaseStats') {
    await chrome.storage.local.set({ [storageKeys.lastView]: '' });
  }
}

async function restoreState() {
  await clearReleaseStatsCache();
  const stored = await chrome.storage.local.get([
    storageKeys.buildId,
    storageKeys.mergedPrs,
    storageKeys.capturedAt,
    storageKeys.lastReport,
    storageKeys.devMergeRows,
    storageKeys.devMergeStartDate,
    storageKeys.devMergeEndDate,
    storageKeys.releaseStatsReleaseNumber,
    storageKeys.releaseNumber,
    storageKeys.lastView
  ]);
  const mergedPrs = stored[storageKeys.mergedPrs] || [];
  const lastReport = stored[storageKeys.lastReport];
  const devMergeRows = stored[storageKeys.devMergeRows] || [];
  const releaseStatsRows = [];
  const releaseStatsWarnings = [];
  const defaults = defaultDateRange();

  devMergeStartDateEl.value = stored[storageKeys.devMergeStartDate] || defaults.startDate;
  devMergeEndDateEl.value = stored[storageKeys.devMergeEndDate] || defaults.endDate;
  releaseStatsReleaseNumberEl.value = stored[storageKeys.releaseStatsReleaseNumber] || '';
  releaseNumberEl.value = stored[storageKeys.releaseNumber] || '';

  if (stored[storageKeys.lastView] === 'deployReport' && lastReport) {
    setStatus(`Есть последний отчет проверки PR. В деплойнице: ${mergedPrs.length}.`);
    setOutput(lastReport);
  } else if (stored[storageKeys.lastView] === 'releaseStats' && releaseStatsRows.length) {
    setStatus(`Есть готовая статистика по релизам: ${releaseStatsRows.length} строк.`);
    setOutput(formatReleaseStatsRows(releaseStatsRows, releaseStatsWarnings));
  } else if (devMergeRows.length) {
    setStatus(`Есть готовые строки для релизной таблицы: ${devMergeRows.length}.`);
    setOutput(formatDevMergeRows(devMergeRows));
  } else if (lastReport) {
    setStatus(`Есть последний отчет. Считанных PR: ${mergedPrs.length}.`);
    setOutput(lastReport);
  } else if (mergedPrs.length) {
    setStatus(`Есть считанные PR: ${mergedPrs.length}.`);
    setOutput(formatMerged(mergedPrs));
  }
}

checkDeployButton.addEventListener('click', checkDeploy);
fetchDevMergeQueueButton.addEventListener('click', fetchDevMergeQueue);
copyDevMergeTsvButton.addEventListener('click', copyDevMergeTsv);
fetchReleaseStatsButton.addEventListener('click', fetchReleaseStats);
copyReleaseStatsTsvButton.addEventListener('click', copyReleaseStatsTsv);
markReleaseThreadsButton.addEventListener('click', markReleaseThreads);
clearDataButton.addEventListener('click', clearData);

restoreState();
