chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'standup:post' || sender.frameId !== 0 || !sender.url) return;
  const page = new URL(sender.url);
  if (page.origin !== 'https://lidia932.github.io' || page.pathname !== '/qa-workbench-pages/standup.html' ||
      !/^[a-z0-9]{26}$/.test(message.id)) return;
  (async () => {
    const response = await fetch('https://roistat.chat.platrum.ru/api/v4/posts/' + message.id,
      {credentials: 'include', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000)});
    if (!response.ok) throw new Error('Platrum: HTTP ' + response.status + '. Проверьте вход и доступ к сообщению.');
    const post = await response.json();
    if (post.id !== message.id || typeof post.message !== 'string') throw new Error('Platrum не вернул сообщение.');
    const match = post.message.match(/^(?:[\s*#_]*?)Сегодня\s*:?[*_ \t]*\r?\n([\s\S]*?)(?=^[ \t*#_]*(?:Проблемы|Вчера)\s*:?[*_ \t]*$|(?![\s\S]))/im);
    if (!match) throw new Error('В сообщении не найден раздел «Сегодня».');
    reply({today: match[1], date: post.create_at});
  })().catch(error => reply({error: error.message}));
  return true;
});
