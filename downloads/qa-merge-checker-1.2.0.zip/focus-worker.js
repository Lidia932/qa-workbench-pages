const focusOperations = new Set([
  'add_user_to_focus_group', 'remove_user_from_focus_group',
  'add_project_to_marketplace_focus_group', 'remove_project_from_marketplace_focus_group',
  'remove_all_users_from_focus_groups', 'show_user_focus_groups', 'show_project_marketplace_focus_groups',
  'get_users_with_focus_group', 'get_users_without_focus_group_by_visits',
  'get_users_with_active_channel_without_focus_group', 'get_projects_by_users', 'get_projects_with_integration',
  'get_projects_with_marketplace_focus_group', 'add_users_to_focus_group_for_test',
  'add_projects_to_marketplace_focus_group_for_test', 'remove_all_project_from_marketplace_focus_group',
  'send_sms', 'help'
]);
const activeFocusCommands = new Set();
const chatOrigin = 'https://roistat.chat.platrum.ru';
const toolsChannel = '/api/v4/teams/name/c9d2f3fa6bb6d63bbd9f589250d36698/channels/name/tools-product';

async function sendFocusCommand(command) {
  const options = {credentials: 'include', redirect: 'error', cache: 'no-store'};
  const lookup = await fetch(chatOrigin + toolsChannel, {...options, signal: AbortSignal.timeout(12000)});
  if (!lookup.ok) throw new Error('Канал tools-product недоступен. Проверьте вход в Platrum и доступ к каналу.');
  const channel = await lookup.json();
  if (channel.name !== 'tools-product' || !/^[a-z0-9]{26}$/.test(channel.id) || channel.delete_at) {
    throw new Error('Не удалось определить канал tools-product.');
  }
  const headers = {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'};
  const csrf = await chrome.cookies.get({url: chatOrigin, name: 'MMCSRF'});
  if (csrf) headers['X-CSRF-Token'] = csrf.value;

  let response;
  try {
    response = await fetch(chatOrigin + '/api/v4/commands/execute', {
      ...options, method: 'POST', headers, signal: AbortSignal.timeout(20000),
      body: JSON.stringify({channel_id: channel.id, team_id: channel.team_id, command})
    });
  } catch {
    throw new Error('Ответ от Platrum не получен. Проверьте канал перед повторной отправкой.');
  }
  if (response.status === 401 || response.status === 403) throw new Error('Проверьте вход в Platrum и права на команду.');
  if (!response.ok) throw new Error('Platrum вернул HTTP ' + response.status + '. Проверьте канал перед повторной отправкой.');
  // A login page or a proxy response is not a slash-command acknowledgement.
  const result = await response.json().catch(() => null);
  if (!result || typeof result !== 'object' || Array.isArray(result) || result.error) {
    throw new Error('Platrum не подтвердил команду. Проверьте канал перед повторной отправкой.');
  }
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'fg:send' || sender.frameId !== 0 || !sender.tab || !sender.url) return;
  const page = new URL(sender.url);
  if (page.origin !== 'https://lidia932.github.io' || page.pathname !== '/qa-workbench-pages/focus-groups.html') return;
  const command = message.command;
  if (typeof command !== 'string' || /[\r\n\u0000]/.test(command) || !command.startsWith('/erp ') ||
      !focusOperations.has(command.split(' ')[1])) {
    reply({error: 'Выберите команду ФГ из списка.'});
    return;
  }
  if (activeFocusCommands.has(command)) {
    reply({error: 'Эта команда уже отправляется.'});
    return;
  }
  activeFocusCommands.add(command);
  sendFocusCommand(command).then(() => reply({ok: true}), error => reply({error: error.message}))
    .finally(() => activeFocusCommands.delete(command));
  return true;
});
