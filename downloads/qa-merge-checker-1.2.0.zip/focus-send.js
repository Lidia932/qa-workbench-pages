(() => {
  if (window !== window.top || location.pathname !== '/qa-workbench-pages/focus-groups.html') return;
  const button = document.querySelector('#send-command');
  const form = document.querySelector('#builder');
  if (!button || !form) return;
  button.dataset.ready = 'true';
  document.querySelector('#send-help').hidden = true;
  let pending = false;
  button.addEventListener('click', async event => {
    if (!event.isTrusted || !navigator.userActivation.isActive || pending || button.disabled) return;
    const values = Array.from(form.querySelectorAll('#arguments input'), input => input.value.trim());
    if (!form.reportValidity() || values.some(value => !value)) return;
    const command = ['/erp', form.querySelector('#operation').value, ...values].join(' ');
    if (command !== document.querySelector('#preview').value) return;
    pending = true;
    button.dispatchEvent(new Event('fg-sending'));
    let result;
    try {
      result = await chrome.runtime.sendMessage({type: 'fg:send', command});
      if (!result) throw new Error();
    } catch {
      result = {error: 'Нет ответа от расширения. Проверьте tools-product перед повторной отправкой.'};
    } finally { pending = false; }
    button.dispatchEvent(new CustomEvent('fg-result', {detail: JSON.stringify({...result, command})}));
  });
})();
